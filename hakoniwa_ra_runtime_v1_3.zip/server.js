import http from 'node:http';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import {
  ISLAND_SIZE, MAX_PLANS, MAX_ISLANDS, INITIAL_MONEY, INITIAL_FOOD,
  LAND, LAND_NAMES, COMMANDS, COMMAND_ORDER, DISASTER,
  createClassicMap, normalizeMap, estimate, landName, imageFor, cellDetail,
  processTurn, finalizeTurn, prizeSummary, hasIntel, satelliteSummary, ensureHakoniwaCup, hakoniwaCupSummary, biologySummary
} from './lib/ra-rules.js';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const PUBLIC=path.join(__dirname,'public');
const DATA_ROOT=process.env.DATA_DIR?path.resolve(process.env.DATA_DIR):path.join(__dirname,'data');
const DATA_FILE=path.join(DATA_ROOT,'state.json');
const PORT=Number(process.env.PORT||3000);
const TURN_SECONDS=Number(process.env.TURN_SECONDS||21600); // production default: 6 hours
const SEA_ISLAND_CAPACITY=Math.max(1,Number(process.env.SEA_ISLAND_CAPACITY||MAX_ISLANDS));
const SEA_PREOPEN_AT=Math.min(SEA_ISLAND_CAPACITY,Math.max(1,Number(process.env.SEA_PREOPEN_AT||Math.max(1,SEA_ISLAND_CAPACITY-3))));
const DEBUG_TURN=process.env.DEBUG_TURN==='1';
const BACKUP_TURN=Number(process.env.BACKUP_TURN||12); // supplied config.yaml backup_turn
const BACKUP_TIMES=Number(process.env.BACKUP_TIMES||4); // supplied config.yaml backup_times
const BACKUP_MAX_AGE_DAYS=Math.max(1,Number(process.env.BACKUP_MAX_AGE_DAYS||30));
const ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||''; // mobile equivalent of Config.pm MASTER_PASSWORD; required for /api/admin/*
const SECRET=process.env.APP_SECRET||'change-this-secret-in-production';
const APP_OPERATOR_NAME=String(process.env.APP_OPERATOR_NAME||'Hakoniwa R.A. Mobile 運営').trim().slice(0,100);
const APP_SUPPORT_EMAIL=String(process.env.APP_SUPPORT_EMAIL||'').trim().slice(0,200);
const CORS_ORIGINS=new Set(String(process.env.CORS_ORIGINS||'capacitor://localhost,http://localhost,https://localhost').split(',').map(v=>v.trim()).filter(Boolean));
const AVATARS=[
  {id:'tropical',name:'南国の小島',src:'/avatars/tropical.png'},
  {id:'forest',name:'森林島',src:'/avatars/forest.png'},
  {id:'farm',name:'農業島',src:'/avatars/farm.png'},
  {id:'industry',name:'工業島',src:'/avatars/industry.png'},
  {id:'harbor',name:'港湾島',src:'/avatars/harbor.png'},
  {id:'volcano',name:'火山島',src:'/avatars/volcano.png'},
  {id:'military',name:'軍事島',src:'/avatars/military.png'},
  {id:'snow',name:'雪島',src:'/avatars/snow.png'},
  {id:'resort',name:'観光島',src:'/avatars/resort.png'},
  {id:'monster',name:'怪獣島',src:'/avatars/monster.png'}
];
const AVATAR_IDS=new Set(AVATARS.map(a=>a.id));
const DEFAULT_AVATAR='tropical';
const BOARD_MAX=80;
const BOARD_TEXT_MAX=200;
const STATUS_TEXT_MAX=40;
const ISLAND_NAME_MAX=20;
const ISLAND_RENAME_COST=Math.max(0,Number(process.env.ISLAND_RENAME_COST??500));
const BOARD_PRIVATE_COST=Math.max(0,Number(process.env.BOARD_PRIVATE_COST??100));
const BOARD_SPY_COST=Math.max(0,Number(process.env.BOARD_SPY_COST??1000));
const BOARD_REPORT_DETAIL_MAX=200;
const BOARD_REPORT_MAX=500;
const BOARD_WARNING_MAX=20;
const BOARD_REPORT_REASONS={abuse:'暴言・差別・嫌がらせ',sexual:'性的・不適切な内容',spam:'スパム・荒らし',other:'その他'};
const BOARD_NG_WORDS=String(process.env.BOARD_NG_WORDS||'死ね,殺すぞ,レイプ,強姦,児童ポルノ').split(',').map(v=>v.trim()).filter(Boolean);
let state; let writeChain=Promise.resolve(); const listeners=new Set();

function nowSec(){return Math.floor(Date.now()/1000)}
function rid(prefix='id'){return `${prefix}_${crypto.randomBytes(8).toString('hex')}`}
function json(res,code,body){const data=Buffer.from(JSON.stringify(body));res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Content-Length':data.length,'Cache-Control':'no-store'});res.end(data)}
function readBody(req){return new Promise((resolve,reject)=>{let raw='';req.on('data',c=>{raw+=c;if(raw.length>1_000_000)req.destroy()});req.on('end',()=>{try{resolve(raw?JSON.parse(raw):{})}catch(e){reject(e)}});req.on('error',reject)})}
function b64url(v){return Buffer.from(v).toString('base64url')}
function signToken(payload){const body=b64url(JSON.stringify(payload));const sig=crypto.createHmac('sha256',SECRET).update(body).digest('base64url');return `${body}.${sig}`}
function verifyToken(token){try{const [body,sig]=String(token||'').split('.');const exp=crypto.createHmac('sha256',SECRET).update(body).digest();const got=Buffer.from(sig,'base64url');if(got.length!==exp.length||!crypto.timingSafeEqual(got,exp))return null;const p=JSON.parse(Buffer.from(body,'base64url').toString());return p.exp>nowSec()?p:null}catch{return null}}
function auth(req){const h=req.headers.authorization||'';const p=verifyToken(h.startsWith('Bearer ')?h.slice(7):'');return p?state.users.find(u=>u.id===p.uid):null}
function hashPassword(password,salt=crypto.randomBytes(16).toString('hex')){return `${salt}:${crypto.scryptSync(password,salt,32).toString('hex')}`}
function checkPassword(password,stored){try{const [salt,hash]=stored.split(':');const a=crypto.scryptSync(password,salt,32),b=Buffer.from(hash,'hex');return a.length===b.length&&crypto.timingSafeEqual(a,b)}catch{return false}}
function emit(type,data={}){const msg=`event: ${type}\ndata: ${JSON.stringify(data)}\n\n`;for(const r of listeners){try{r.write(msg)}catch{}}}
async function persist(){syncLegacyClock();await fs.mkdir(path.dirname(DATA_FILE),{recursive:true});const tmp=DATA_FILE+'.tmp';await fs.writeFile(tmp,JSON.stringify(state,null,2));await fs.rename(tmp,DATA_FILE)}
const BACKUP_DIR=path.join(DATA_ROOT,'backups');
const DELETION_LEDGER_FILE=path.join(DATA_ROOT,'deletion-ledger.json');
let deletionLedger={version:1,deletedUsers:[],deletedIslands:[]};
function deletionHash(kind,id){return crypto.createHash('sha256').update(`${kind}:${String(id||'')}`).digest('hex')}
function normalizeDeletionLedger(value){const v=value&&typeof value==='object'?value:{};return {version:1,deletedUsers:Array.isArray(v.deletedUsers)?v.deletedUsers.filter(x=>x&&typeof x.hash==='string').slice(-5000):[],deletedIslands:Array.isArray(v.deletedIslands)?v.deletedIslands.filter(x=>x&&typeof x.hash==='string').slice(-5000):[]}}
async function loadDeletionLedger(){try{deletionLedger=normalizeDeletionLedger(JSON.parse(await fs.readFile(DELETION_LEDGER_FILE,'utf8')))}catch(e){if(e.code!=='ENOENT')throw e;deletionLedger=normalizeDeletionLedger({})}}
async function persistDeletionLedger(){await fs.mkdir(DATA_ROOT,{recursive:true});const tmp=DELETION_LEDGER_FILE+'.tmp';await fs.writeFile(tmp,JSON.stringify(deletionLedger,null,2));await fs.rename(tmp,DELETION_LEDGER_FILE)}
function ledgerHas(kind,id){if(!id)return false;const hash=deletionHash(kind,id),list=kind==='user'?deletionLedger.deletedUsers:deletionLedger.deletedIslands;return list.some(x=>x.hash===hash)}
async function recordDeletion(userId,islandId){const at=Date.now();const uh=deletionHash('user',userId),ih=deletionHash('island',islandId);if(!deletionLedger.deletedUsers.some(x=>x.hash===uh))deletionLedger.deletedUsers.push({hash:uh,at});if(!deletionLedger.deletedIslands.some(x=>x.hash===ih))deletionLedger.deletedIslands.push({hash:ih,at});deletionLedger=normalizeDeletionLedger(deletionLedger);await persistDeletionLedger()}
function applyDeletionLedger(s){if(!s||typeof s!=='object')return s;const removedUsers=new Set((s.users||[]).filter(u=>ledgerHas('user',u.id)).map(u=>u.id));const removedIslands=new Set((s.islands||[]).filter(i=>ledgerHas('island',i.id)||removedUsers.has(i.ownerId)).map(i=>i.id));s.users=(s.users||[]).filter(u=>!removedUsers.has(u.id));s.islands=(s.islands||[]).filter(i=>!removedIslands.has(i.id));for(const island of s.islands){island.board=(island.board||[]).filter(post=>!removedIslands.has(post?.realAuthorIslandId||post?.authorIslandId));if(island.boardRead&&typeof island.boardRead==='object')for(const id of removedIslands)delete island.boardRead[id];if(island.intel&&typeof island.intel==='object')for(const id of removedIslands)delete island.intel[id];island.plans=(island.plans||[]).filter(p=>!removedIslands.has(p.targetId))}s.boardReports=(s.boardReports||[]).filter(r=>!removedUsers.has(r.reporterUserId)&&!removedIslands.has(r.reporterIslandId)&&!removedIslands.has(r.realAuthorIslandId)&&!removedIslands.has(r.targetIslandId));return s}
async function scrubBackupsByLedger(){for(let i=0;i<BACKUP_TIMES;i++){const f=path.join(BACKUP_DIR,`state.bak${i}.json`);try{const snap=applyDeletionLedger(migrateState(JSON.parse(await fs.readFile(f,'utf8'))));await fs.writeFile(f,JSON.stringify(snap,null,2))}catch(e){if(e.code!=='ENOENT')throw e}}}
async function pruneExpiredBackups(){const cutoff=Date.now()-BACKUP_MAX_AGE_DAYS*86400000;for(let i=0;i<BACKUP_TIMES;i++){const f=path.join(BACKUP_DIR,`state.bak${i}.json`);try{const st=await fs.stat(f);if(st.mtimeMs<cutoff)await fs.rm(f,{force:true})}catch(e){if(e.code!=='ENOENT')throw e}}}
function applyCors(req,res){const origin=String(req.headers.origin||'');if(origin&&CORS_ORIGINS.has(origin)){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type');res.setHeader('Access-Control-Allow-Methods','GET, POST, PATCH, DELETE, OPTIONS')}}
function adminOK(password){if(!ADMIN_PASSWORD)return false;const a=Buffer.from(String(password||'')),b=Buffer.from(ADMIN_PASSWORD);return a.length===b.length&&crypto.timingSafeEqual(a,b)}
async function rotateBackupSnapshot(){await fs.mkdir(BACKUP_DIR,{recursive:true});await pruneExpiredBackups();for(let i=BACKUP_TIMES-1;i>=0;i--){const src=path.join(BACKUP_DIR,`state.bak${i}.json`);if(i===BACKUP_TIMES-1){await fs.rm(src,{force:true});continue}const dst=path.join(BACKUP_DIR,`state.bak${i+1}.json`);try{await fs.rename(src,dst)}catch(e){if(e.code!=='ENOENT')throw e}}await fs.writeFile(path.join(BACKUP_DIR,'state.bak0.json'),JSON.stringify(state,null,2))}
async function backupInfo(){await pruneExpiredBackups();const out=[];for(let i=0;i<BACKUP_TIMES;i++){const f=path.join(BACKUP_DIR,`state.bak${i}.json`);try{const st=await fs.stat(f);const snap=JSON.parse(await fs.readFile(f,'utf8'));const seas=Array.isArray(snap.seas)?snap.seas.map(x=>({id:Number(x.id||1),turn:Number(x.turn||0),lastTurnAt:Number(x.lastTurnAt||0)})):[{id:1,turn:Number(snap.turn||0),lastTurnAt:Number(snap.lastTurnAt||0)}];out.push({slot:i,turn:seas[0]?.turn||0,lastTurnAt:seas[0]?.lastTurnAt||0,islands:(snap.islands||[]).length,seas,mtimeMs:st.mtimeMs})}catch(e){if(e.code!=='ENOENT')throw e}}return out}
function seaName(id){return `第${Number(id)}海域`}
function createSea(id,{turn=0,lastTurnAt=nowSec(),createdAt=Date.now(),startedAt=null,status='open',globalLogs=[]}={}){return {id:Number(id),name:seaName(id),turn:Number(turn)||0,lastTurnAt:Number(lastTurnAt)||nowSec(),createdAt:Number(createdAt)||Date.now(),startedAt:startedAt?Number(startedAt):null,status:status==='full'?'full':'open',globalLogs:Array.isArray(globalLogs)?globalLogs.slice(0,80):[]}}
function freshState(){const first=createSea(1,{lastTurnAt:nowSec()-nowSec()%TURN_SECONDS});return {version:11,turn:first.turn,lastTurnAt:first.lastTurnAt,users:[],islands:[],seas:[first],globalLogs:first.globalLogs,boardReports:[],supportMessages:[]}}
function migrateUser(u){u.boardPostingSuspended=!!u.boardPostingSuspended;u.moderationWarnings=Array.isArray(u.moderationWarnings)?u.moderationWarnings.slice(0,BOARD_WARNING_MAX):[];return u}
function realAuthorId(post){return post?.realAuthorIslandId||post?.authorIslandId||null}
function migrateBoardPost(post){if(!post||typeof post!=='object')return post;post.realAuthorIslandId=realAuthorId(post);return post}
function migrateReport(report){if(!report||typeof report!=='object')return report;report.status=report.status==='resolved'?'resolved':'open';report.realAuthorIslandId=report.realAuthorIslandId||null;return report}
function seaById(id){return state?.seas?.find(s=>s.id===Number(id))||null}
function islandsInSea(seaId,{aliveOnly=false}={}){return (state?.islands||[]).filter(i=>i.seaId===Number(seaId)&&(!aliveOnly||!i.dead))}
function publicSea(sea){const count=islandsInSea(sea.id).length,status=count>=SEA_ISLAND_CAPACITY?'full':'open';return {id:sea.id,name:sea.name||seaName(sea.id),turn:sea.turn,lastTurnAt:sea.lastTurnAt,createdAt:sea.createdAt,startedAt:sea.startedAt,status,islandCount:count,maxIslands:SEA_ISLAND_CAPACITY,registrationOpen:count<SEA_ISLAND_CAPACITY}}
function nextSeaIdFor(s){return Math.max(0,...(s?.seas||[]).map(sea=>Number(sea.id)||0))+1}
function normalizeSeaAvailabilityFor(s){s.seas=(s.seas||[]).sort((a,b)=>a.id-b.id);const count=id=>(s.islands||[]).filter(i=>i.seaId===Number(id)).length;for(const sea of s.seas)sea.status=count(sea.id)>=SEA_ISLAND_CAPACITY?'full':'open';const newest=s.seas.at(-1);if(newest&&count(newest.id)>=SEA_PREOPEN_AT){const id=nextSeaIdFor(s);s.seas.push(createSea(id,{lastTurnAt:nowSec()}))}if(!s.seas.length)s.seas.push(createSea(1,{lastTurnAt:nowSec()}));const first=s.seas.find(x=>x.id===1)||s.seas[0];if(first){s.turn=first.turn;s.lastTurnAt=first.lastTurnAt;s.globalLogs=first.globalLogs}}
function normalizeSeaAvailability(){normalizeSeaAvailabilityFor(state)}
function registrationSea(){normalizeSeaAvailability();return [...state.seas].reverse().find(sea=>islandsInSea(sea.id).length<SEA_ISLAND_CAPACITY)||state.seas.at(-1)}
function islandForUser(user){return user?state.islands.find(i=>i.ownerId===user.id):null}
function seaForIsland(island){return island?seaById(island.seaId):null}
function turnForIsland(island){return seaForIsland(island)?.turn??Number(island?.turn||0)}
function resolveSeaForRequest(req,url){const user=auth(req),own=islandForUser(user);if(own)return seaForIsland(own)||state.seas[0];const q=Number(url?.searchParams?.get('seaId'));if(Number.isInteger(q)&&q>0){const selected=seaById(q);if(selected)return selected}return registrationSea()||state.seas[0]}
function syncLegacyClock(){if(!state)return;const first=(state.seas||[]).find(s=>s.id===1)||state.seas?.[0];if(first){state.turn=first.turn;state.lastTurnAt=first.lastTurnAt;state.globalLogs=first.globalLogs}}
function migrateState(s){const legacyTurn=Number(s.turn||0),legacyLast=Number(s.lastTurnAt||nowSec()),legacyLogs=Array.isArray(s.globalLogs)?s.globalLogs:[];s.users=(s.users||[]).map(migrateUser);s.islands=(s.islands||[]).map(migrateIsland);for(const island of s.islands){if(!Number.isInteger(Number(island.seaId))||Number(island.seaId)<1)island.seaId=1;else island.seaId=Number(island.seaId)}if(Array.isArray(s.seas)&&s.seas.length){s.seas=s.seas.map(x=>createSea(x.id||1,{turn:x.turn,lastTurnAt:x.lastTurnAt,createdAt:x.createdAt,startedAt:x.startedAt,status:x.status,globalLogs:x.globalLogs}))}else{s.seas=[createSea(1,{turn:legacyTurn,lastTurnAt:legacyLast,createdAt:Date.now(),startedAt:s.islands.length?Date.now():null,status:s.islands.length>=SEA_ISLAND_CAPACITY?'full':'open',globalLogs:legacyLogs})]}const known=new Set(s.seas.map(x=>x.id));for(const island of s.islands)if(!known.has(island.seaId)){s.seas.push(createSea(island.seaId));known.add(island.seaId)}s.version=11;s.boardReports=Array.isArray(s.boardReports)?s.boardReports.map(migrateReport).slice(0,BOARD_REPORT_MAX):[];s.supportMessages=Array.isArray(s.supportMessages)?s.supportMessages.slice(0,200):[];normalizeSeaAvailabilityFor(s);return s}
function mutate(fn){const run=writeChain.catch(()=>{}).then(async()=>{const out=await fn();syncLegacyClock();await persist();return out});writeChain=run.catch(()=>{});return run}
function migrateIsland(i){i.seaId=Number.isInteger(Number(i.seaId))&&Number(i.seaId)>0?Number(i.seaId):1;i.avatarId=AVATAR_IDS.has(i.avatarId)?i.avatarId:DEFAULT_AVATAR;i.statusMessage=String(i.statusMessage||'').replace(/[\r\n]+/g,' ').trim().slice(0,STATUS_TEXT_MAX);i.map=normalizeMap(i.map||createClassicMap());i.plans??=[];i.logs??=[];i.board=Array.isArray(i.board)?i.board.map(migrateBoardPost).filter(Boolean).slice(0,BOARD_MAX):[];i.boardRead=(i.boardRead&&typeof i.boardRead==='object'&&!Array.isArray(i.boardRead))?i.boardRead:{};i.money=Number.isFinite(i.money)?i.money:INITIAL_MONEY;i.food=Number.isFinite(i.food)?i.food:INITIAL_FOOD;i.absent??=0;i.prepare2??=0;i.propaganda??=0;i.monsterSend??=0;i.bigmissile??=0;i.intel??={};i.prize??='0,0,';i.dead??=false;i.tourists=Math.max(0,Math.trunc(Number(i.tourists??i.eisei2)||0));i.eisei2=i.tourists;i.eisei1=Math.max(0,Math.min(100,Math.trunc(Number(i.eisei1)||0)));delete i.relocationStock;delete i.magic;estimate(i);ensureHakoniwaCup(i);return i}
function normalizeModerationText(value){return String(value||'').normalize('NFKC').toLowerCase().replace(/[\s\u3000・･_＿.。!！?？,，、\-ー~〜～]+/g,'')}
function blockedBoardWord(text){const normalized=normalizeModerationText(text);return BOARD_NG_WORDS.find(word=>normalized.includes(normalizeModerationText(word)))||null}
function normalizeIslandNameInput(value){return String(value||'').trim().replace(/島+$/u,'').trim()}
function islandNameError(name){if(name.length<1||name.length>ISLAND_NAME_MAX)return `島名は1〜${ISLAND_NAME_MAX}文字で入力してください（末尾の「島」は自動で付くため入力不要です）。`;if(/[?,()<>$]/.test(name)||name==='無人')return 'その島名は使用できません。';return ''}
function removeOrphanUsers(){const owners=new Set((state.islands||[]).map(i=>i.ownerId).filter(Boolean));const removed=(state.users||[]).filter(u=>!owners.has(u.id));if(removed.length)state.users=(state.users||[]).filter(u=>owners.has(u.id));return removed}
function userForIslandId(islandId){const island=state.islands.find(i=>i.id===islandId);return island?state.users.find(u=>u.id===island.ownerId):null}
function canViewBoardPost(target,post,user){if(post.visibility==='public')return true;if(!user)return false;const viewerIsland=state.islands.find(i=>i.ownerId===user.id);return target.ownerId===user.id||!!viewerIsland&&realAuthorId(post)===viewerIsland.id}
function publicModeration(user){return {boardPostingSuspended:!!user.boardPostingSuspended,moderationWarnings:(user.moderationWarnings||[]).slice(0,BOARD_WARNING_MAX).map(w=>({id:w.id,at:w.at,message:w.message}))}}
function adminReportView(report){const target=state.islands.find(i=>i.id===report.targetIslandId),real=state.islands.find(i=>i.id===report.realAuthorIslandId),display=state.islands.find(i=>i.id===report.displayAuthorIslandId),reporter=state.islands.find(i=>i.id===report.reporterIslandId),authorUser=userForIslandId(report.realAuthorIslandId);const livePost=(target?.board||[]).find(p=>p.id===report.postId);return {...report,targetIslandName:target?.name||report.targetIslandName||'消滅した島',realAuthorIslandName:real?.name||report.realAuthorIslandName||'消滅した島',displayAuthorIslandName:display?.name||report.displayAuthorIslandName||'消滅した島',reporterIslandName:reporter?.name||report.reporterIslandName||'消滅した島',postExists:!!livePost,authorSuspended:!!authorUser?.boardPostingSuspended}}
function resolveReportsForPost(targetIslandId,postId,action){for(const r of state.boardReports||[]){if(r.targetIslandId===targetIslandId&&r.postId===postId&&r.status!=='resolved'){r.status='resolved';r.handledAt=Date.now();r.action=action}}}
async function load(){await loadDeletionLedger();await pruneExpiredBackups();try{state=applyDeletionLedger(migrateState(JSON.parse(await fs.readFile(DATA_FILE,'utf8'))));await persist()}catch{state=applyDeletionLedger(freshState());await persist()}}
function shuffled(arr){const a=[...arr];for(let i=a.length-1;i>0;i--){const j=crypto.randomInt(0,i+1);[a[i],a[j]]=[a[j],a[i]]}return a}
function publicMapCell(c,privileged,turn){
  if(privileged)return {...c,name:landName(c),detail:cellDetail(c,true),image:imageFor(c,true,turn)};
  if(c.kind===LAND.BASE){const v={kind:LAND.FOREST,value:0};return {...v,name:landName(v),detail:cellDetail(v,false),image:imageFor(c,false,turn)}}
  if(c.kind===LAND.SBASE){const v={kind:LAND.SEA,value:0};return {...v,name:landName(v),detail:cellDetail(v,false),image:imageFor(c,false,turn)}}
  const v={kind:c.kind,value:c.value};return {...v,name:landName(v),detail:cellDetail(v,false),image:imageFor(c,false,turn)};
}
function publicIsland(i,detail=false,owner=false,intel=false){estimate(i);const privileged=owner||intel,sea=seaForIsland(i),turn=sea?.turn??i.turn??0;const avatar=AVATARS.find(a=>a.id===i.avatarId)||AVATARS[0];const base={id:i.id,seaId:i.seaId,seaName:sea?.name||seaName(i.seaId),name:i.name,statusMessage:i.statusMessage||'',avatarId:avatar.id,avatarName:avatar.name,avatarUrl:avatar.src,money:i.money,food:i.food,turn,updatedAt:i.updatedAt,population:i.pop,area:i.area,farm:i.farm,factory:i.factory,mountain:i.mountain,points:i.pts||0,taxRate:i.eisei1||0,houses:i.hou||0,embassies:i.tai||0,tourists:Math.max(0,Math.trunc(Number(i.tourists??i.eisei2)||0)),dead:!!i.dead,prizes:prizeSummary(i),satellites:satelliteSummary(i),hakoniwaCup:hakoniwaCupSummary(i),intelRevealed:!!intel};if(detail)Object.assign(base,{map:i.map.map(row=>row.map(c=>publicMapCell(c,privileged,turn))),plans:owner?i.plans:[],logs:(i.logs||[]).filter(l=>owner||!l.secret).slice(0,50),biology:owner?biologySummary(i):null});return base}

function publicBoard(target,user){
  const viewerIsland=user?state.islands.find(i=>i.ownerId===user.id):null;
  const owner=!!user&&target.ownerId===user.id;
  return (target.board||[]).filter(post=>canViewBoardPost(target,post,user)).map(post=>{
    const realId=realAuthorId(post),realAuthor=state.islands.find(i=>i.id===realId);
    const displayAuthor=post.spyIslandId?state.islands.find(i=>i.id===post.spyIslandId):realAuthor;
    const avatar=displayAuthor?AVATARS.find(a=>a.id===displayAuthor.avatarId):null;
    const ownPost=!!viewerIsland&&realId===viewerIsland.id;
    return {
      id:post.id,turn:post.turn,at:post.at,text:post.text,visibility:post.visibility,
      authorIslandId:displayAuthor?.id||post.spyIslandId||post.authorIslandId,
      authorIslandName:displayAuthor?.name||post.displayIslandName||post.authorIslandName||'消滅した島',
      authorAvatarUrl:avatar?.src||'/avatars/tropical.png',
      ownPost,
      spyOwn:ownPost&&!!post.spyIslandId,
      canDelete:!!user&&(owner||ownPost),
      canReport:!!user&&!!viewerIsland&&!ownPost
    };
  });
}

function boardUnreadCount(target,user){
  if(!user)return 0;
  const viewerIsland=state.islands.find(i=>i.ownerId===user.id);if(!viewerIsland)return 0;
  const since=Number(viewerIsland.boardRead?.[target.id]||0),owner=target.ownerId===user.id;
  return (target.board||[]).filter(post=>{
    const realId=realAuthorId(post),visible=post.visibility==='public'||owner||realId===viewerIsland.id;
    return visible&&Number(post.at||0)>since&&realId!==viewerIsland.id;
  }).length;
}


async function advanceSeaTurn(seaId){const targetSea=seaById(seaId);if(!targetSea)return;await mutate(async()=>{const sea=seaById(seaId);if(!sea)return;if(BACKUP_TURN>0&&BACKUP_TIMES>0&&((sea.turn+1)%BACKUP_TURN)===0)await rotateBackupSnapshot();sea.turn++;sea.lastTurnAt+=TURN_SECONDS;const scoped={islands:state.islands.filter(i=>i.seaId===sea.id),globalLogs:sea.globalLogs||[]};for(const island of shuffled(scoped.islands.filter(i=>!i.dead))){island.turn=sea.turn;processTurn(scoped,island,sea.turn)}finalizeTurn(scoped,sea.turn);sea.globalLogs=scoped.globalLogs||[];state.islands=state.islands.filter(i=>!i.dead);removeOrphanUsers();sea.globalLogs.unshift({turn:sea.turn,at:Date.now(),text:`${sea.name} ターン${sea.turn}を処理しました。`});sea.globalLogs=sea.globalLogs.slice(0,80)});const sea=seaById(seaId);emit('turn',{seaId,turn:sea?.turn||0,lastTurnAt:sea?.lastTurnAt||0});emit('islands',{seaId,turn:sea?.turn||0})}
async function maybeAdvance(){for(const sea of [...(state.seas||[])]){if(islandsInSea(sea.id,{aliveOnly:true}).length===0)continue;let guard=0;while(nowSec()-sea.lastTurnAt>=TURN_SECONDS&&guard++<8)await advanceSeaTurn(sea.id)}}
function addAutoPlans(island,kind,amount=0){
  if(kind==='clearPlans'){island.plans=[];return}
  const candidates=[];for(let y=0;y<ISLAND_SIZE;y++)for(let x=0;x<ISLAND_SIZE;x++)candidates.push({x,y,c:island.map[y][x]});
  const points=shuffled(candidates),push=(plan)=>{if(island.plans.length>=MAX_PLANS)return false;island.plans.push({id:rid('plan'),targetId:null,amount:0,createdAt:Date.now(),...plan});return true};
  if(kind==='autoPrepare'||kind==='autoLevel'){
    const cmd=kind==='autoPrepare'?'prepare':'level';for(const {x,y,c} of points){if(c.kind===LAND.WASTE&&!push({kind:cmd,x,y}))break}return;
  }
  if(kind==='autoReclaim'){for(const {x,y,c} of points){if(c.kind===LAND.SEA&&c.value===1&&!push({kind:'reclaim',x,y}))break}return;}
  if(kind==='autoDestroy'){for(const {x,y,c} of points){if(c.kind===LAND.SEA&&c.value===1&&!push({kind:'destroy',x,y}))break}return;}
  if(kind==='autoYoyaku'){for(const {x,y,c} of points){if(c.kind===LAND.PLAINS&&!push({kind:'yoyaku',x,y}))break}return;}
  if(kind==='autoSellTree'||kind==='autoForestry'){
    const threshold=Math.max(0,Number(amount)||0)*2;let slots=0;
    for(const {x,y,c} of points){if(c.kind!==LAND.FOREST||c.value<=threshold)continue;if(slots>=MAX_PLANS-1||island.plans.length>=MAX_PLANS)break;
      if(kind==='autoForestry'){if(!push({kind:'plant',x,y}))break;slots++;}
      if(!push({kind:'sellTree',x,y}))break;slots++;
    }return;
  }
}

const MIME={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.gif':'image/gif','.svg':'image/svg+xml','.png':'image/png','.webmanifest':'application/manifest+json'};
async function serveStatic(req,res,urlPath){let rel=urlPath==='/'?'/index.html':urlPath;rel=path.normalize(rel).replace(/^(\.\.(\/|\\|$))+/,'');const full=path.join(PUBLIC,rel);if(!full.startsWith(PUBLIC))return false;try{const st=await fs.stat(full);if(!st.isFile())return false;const data=await fs.readFile(full);const ext=path.extname(full);const base=path.basename(full);const noCache=ext==='.html'||base==='sw.js'||base==='app.js'||base==='style.css'||base==='manifest.webmanifest';res.writeHead(200,{'Content-Type':MIME[ext]||'application/octet-stream','Content-Length':data.length,'Cache-Control':noCache?'no-cache':'public, max-age=3600'});res.end(data);return true}catch{return false}}

const server=http.createServer(async(req,res)=>{try{
  applyCors(req,res);if(req.method==='OPTIONS'){res.writeHead(204);res.end();return}
  const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  if(url.pathname==='/api/events'&&req.method==='GET'){res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive','X-Accel-Buffering':'no'});res.write(`event: hello\ndata: ${JSON.stringify({seas:(state.seas||[]).map(publicSea)})}\n\n`);listeners.add(res);req.on('close',()=>listeners.delete(res));return}
  if(url.pathname==='/api/meta'&&req.method==='GET'){const sea=resolveSeaForRequest(req,url);return json(res,200,{version:18,title:'Hakoniwa R.A. Mobile',turn:sea.turn,lastTurnAt:sea.lastTurnAt,turnSeconds:TURN_SECONDS,islandSize:ISLAND_SIZE,maxPlans:MAX_PLANS,maxIslands:SEA_ISLAND_CAPACITY,maxIslandsPerSea:SEA_ISLAND_CAPACITY,seaPreopenAt:SEA_PREOPEN_AT,sea:publicSea(sea),seas:(state.seas||[]).map(publicSea),commands:Object.fromEntries(COMMAND_ORDER.map(k=>[k,COMMANDS[k]])),landNames:LAND_NAMES,disaster:DISASTER,debugTurn:DEBUG_TURN,backupTurn:BACKUP_TURN,backupTimes:BACKUP_TIMES,backupMaxAgeDays:BACKUP_MAX_AGE_DAYS,adminEnabled:!!ADMIN_PASSWORD,source:'Hakoniwa R.A. 030314 compatibility port on verified Hakoniwa 2 Mobile baseline; user-trimmed scope removes Boku2 terrain relocation, embassies, and railway while retaining owner relocation, house/tax, monster/biology, tourism, satellites and Hakoniwa Cup; magic-school and electricity branches remain intentionally omitted',assetCount:127,assetMode:'R.A. 030314 development assets',avatars:AVATARS,boardMax:BOARD_MAX,boardTextMax:BOARD_TEXT_MAX,statusTextMax:STATUS_TEXT_MAX,islandNameMax:ISLAND_NAME_MAX,islandRenameCost:ISLAND_RENAME_COST,boardPrivateCost:BOARD_PRIVATE_COST,boardSpyCost:BOARD_SPY_COST,boardReportReasons:BOARD_REPORT_REASONS,hakoniwaCup:{cycleTurns:100,qualifyingTurns:[1,11,21,31],top8Turn:41,quarterfinalTurn:42,semifinalTurn:47,finalTurn:50,resetTurn:52},compatibility:'RA Mobile v1.3 Phase 10: heavy-tax riots restored; ice excluded and rotten sea included in island area; weather/observation/intercept/defense satellite charge contributes to resort revenue; agricultural/industrial university bias retained; user-scope trims remain in force'})}
  if(url.pathname==='/api/legal'&&req.method==='GET')return json(res,200,{operatorName:APP_OPERATOR_NAME,supportEmail:APP_SUPPORT_EMAIL,policyUpdated:'2026-08-19'});
  if(url.pathname==='/api/seas'&&req.method==='GET')return json(res,200,{seas:(state.seas||[]).map(publicSea),registrationSea:publicSea(registrationSea())});
  if(url.pathname==='/api/support'&&req.method==='POST'){const b=await readBody(req),user=auth(req),island=user?state.islands.find(i=>i.ownerId===user.id):null,category=String(b.category||'other'),email=String(b.email||'').trim().slice(0,200),message=String(b.message||'').trim();if(!['account','bug','privacy','other'].includes(category))return json(res,400,{error:'お問い合わせ種別が不正です。'});if(!message||message.length>1000)return json(res,400,{error:'お問い合わせ内容は1〜1000文字で入力してください。'});if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return json(res,400,{error:'メールアドレスの形式を確認してください。'});let ticket;await mutate(()=>{ticket={id:rid('support'),at:Date.now(),status:'open',category,email,message,userId:user?.id||null,islandId:island?.id||null,islandName:island?.name||null,seaId:island?.seaId||null,seaName:island?seaForIsland(island)?.name||seaName(island.seaId):null};state.supportMessages??=[];state.supportMessages.unshift(ticket);state.supportMessages=state.supportMessages.slice(0,200)});return json(res,201,{ok:true,ticketId:ticket.id})};
  if(url.pathname==='/api/admin/status'&&req.method==='POST'){const b=await readBody(req);if(!ADMIN_PASSWORD)return json(res,503,{error:'ADMIN_PASSWORDが設定されていません。'});if(!adminOK(b.password))return json(res,403,{error:'管理パスワードが違います。'});const first=seaById(1)||state.seas[0];return json(res,200,{turn:first.turn,lastTurnAt:first.lastTurnAt,lastTurnAtIso:new Date(first.lastTurnAt*1000).toISOString(),islands:state.islands.length,users:state.users.length,seas:(state.seas||[]).map(publicSea),openReports:(state.boardReports||[]).filter(r=>r.status!=='resolved').length,suspendedUsers:state.users.filter(u=>u.boardPostingSuspended).length,openSupport:(state.supportMessages||[]).filter(m=>m.status!=='resolved').length,deletionLedger:{users:deletionLedger.deletedUsers.length,islands:deletionLedger.deletedIslands.length},backups:await backupInfo()})}
  if(url.pathname==='/api/admin/support'&&req.method==='POST'){const b=await readBody(req);if(!ADMIN_PASSWORD)return json(res,503,{error:'ADMIN_PASSWORDが設定されていません。'});if(!adminOK(b.password))return json(res,403,{error:'管理パスワードが違います。'});return json(res,200,{messages:state.supportMessages||[]})}
  const asm=url.pathname.match(/^\/api\/admin\/support\/([^/]+)\/resolve$/);if(asm&&req.method==='POST'){const b=await readBody(req);if(!ADMIN_PASSWORD)return json(res,503,{error:'ADMIN_PASSWORDが設定されていません。'});if(!adminOK(b.password))return json(res,403,{error:'管理パスワードが違います。'});const message=(state.supportMessages||[]).find(m=>m.id===asm[1]);if(!message)return json(res,404,{error:'お問い合わせが見つかりません。'});await mutate(()=>{message.status='resolved';message.resolvedAt=Date.now()});return json(res,200,{ok:true})}
  if(url.pathname==='/api/admin/backup'&&req.method==='POST'){const b=await readBody(req);if(!ADMIN_PASSWORD)return json(res,503,{error:'ADMIN_PASSWORDが設定されていません。'});if(!adminOK(b.password))return json(res,403,{error:'管理パスワードが違います。'});await mutate(async()=>{await rotateBackupSnapshot()});return json(res,200,{ok:true,backups:await backupInfo()})}
  if(url.pathname==='/api/admin/reset'&&req.method==='POST'){const b=await readBody(req);if(!ADMIN_PASSWORD)return json(res,503,{error:'ADMIN_PASSWORDが設定されていません。'});if(!adminOK(b.password))return json(res,403,{error:'管理パスワードが違います。'});await mutate(async()=>{await rotateBackupSnapshot();state=freshState()});emit('islands',{reason:'admin-reset'});emit('turn',{turn:state.turn,lastTurnAt:state.lastTurnAt});return json(res,200,{ok:true,turn:state.turn})}
  const ar=url.pathname.match(/^\/api\/admin\/restore\/(\d+)$/);if(ar&&req.method==='POST'){const b=await readBody(req);if(!ADMIN_PASSWORD)return json(res,503,{error:'ADMIN_PASSWORDが設定されていません。'});if(!adminOK(b.password))return json(res,403,{error:'管理パスワードが違います。'});const slot=Number(ar[1]);if(slot<0||slot>=BACKUP_TIMES)return json(res,400,{error:'バックアップ番号が不正です。'});const f=path.join(BACKUP_DIR,`state.bak${slot}.json`);let snap;try{snap=JSON.parse(await fs.readFile(f,'utf8'))}catch(e){if(e.code==='ENOENT')return json(res,404,{error:'そのバックアップはありません。'});throw e}await mutate(async()=>{await rotateBackupSnapshot();state=applyDeletionLedger(migrateState(snap))});emit('islands',{reason:'admin-restore'});emit('turn',{turn:state.turn,lastTurnAt:state.lastTurnAt});return json(res,200,{ok:true,turn:state.turn})}
  const ad=url.pathname.match(/^\/api\/admin\/backups\/(\d+)$/);if(ad&&req.method==='DELETE'){const b=await readBody(req);if(!ADMIN_PASSWORD)return json(res,503,{error:'ADMIN_PASSWORDが設定されていません。'});if(!adminOK(b.password))return json(res,403,{error:'管理パスワードが違います。'});const slot=Number(ad[1]);if(slot<0||slot>=BACKUP_TIMES)return json(res,400,{error:'バックアップ番号が不正です。'});await fs.rm(path.join(BACKUP_DIR,`state.bak${slot}.json`),{force:true});return json(res,200,{ok:true,backups:await backupInfo()})}
  if(url.pathname==='/api/admin/turn-clock'&&req.method==='POST'){const b=await readBody(req);if(!ADMIN_PASSWORD)return json(res,503,{error:'ADMIN_PASSWORDが設定されていません。'});if(!adminOK(b.password))return json(res,403,{error:'管理パスワードが違います。'});const t=Number(b.lastTurnAt),seaId=Math.max(1,Number(b.seaId||1));if(!Number.isFinite(t)||t<0)return json(res,400,{error:'lastTurnAtはUnix秒で指定してください。'});const sea=seaById(seaId);if(!sea)return json(res,404,{error:'海域が見つかりません。'});await mutate(()=>{sea.lastTurnAt=Math.floor(t)});emit('turn',{seaId:sea.id,turn:sea.turn,lastTurnAt:sea.lastTurnAt});return json(res,200,{ok:true,seaId:sea.id,lastTurnAt:sea.lastTurnAt})}
  if(url.pathname==='/api/admin/reports'&&req.method==='POST'){const b=await readBody(req);if(!ADMIN_PASSWORD)return json(res,503,{error:'ADMIN_PASSWORDが設定されていません。'});if(!adminOK(b.password))return json(res,403,{error:'管理パスワードが違います。'});return json(res,200,{reports:(state.boardReports||[]).map(adminReportView),reasons:BOARD_REPORT_REASONS})}
  const mara=url.pathname.match(/^\/api\/admin\/reports\/([^/]+)\/action$/);if(mara&&req.method==='POST'){
    const b=await readBody(req);if(!ADMIN_PASSWORD)return json(res,503,{error:'ADMIN_PASSWORDが設定されていません。'});if(!adminOK(b.password))return json(res,403,{error:'管理パスワードが違います。'});
    const report=(state.boardReports||[]).find(r=>r.id===mara[1]);if(!report)return json(res,404,{error:'通報が見つかりません。'});const action=String(b.action||''),allowed=new Set(['delete','warn','suspend','unsuspend','dismiss']);if(!allowed.has(action))return json(res,400,{error:'管理操作が不正です。'});
    let boardChanged=false;await mutate(()=>{const authorUser=userForIslandId(report.realAuthorIslandId);const target=state.islands.find(i=>i.id===report.targetIslandId);if(action==='delete'){if(target){const before=(target.board||[]).length;target.board=(target.board||[]).filter(p=>p.id!==report.postId);boardChanged=target.board.length!==before;if(boardChanged)target.updatedAt=Date.now()}resolveReportsForPost(report.targetIslandId,report.postId,'delete');report.status='resolved';report.handledAt=Date.now();report.action='delete'}else if(action==='warn'){if(!authorUser)throw Object.assign(new Error('投稿者アカウントが存在しません。'),{status:404});const message=String(b.message||'掲示板の利用ルールに反する投稿が確認されました。').trim().slice(0,200);authorUser.moderationWarnings??=[];authorUser.moderationWarnings.unshift({id:rid('warn'),at:Date.now(),message});authorUser.moderationWarnings=authorUser.moderationWarnings.slice(0,BOARD_WARNING_MAX);report.status='resolved';report.handledAt=Date.now();report.action='warn'}else if(action==='suspend'){if(!authorUser)throw Object.assign(new Error('投稿者アカウントが存在しません。'),{status:404});authorUser.boardPostingSuspended=true;report.status='resolved';report.handledAt=Date.now();report.action='suspend'}else if(action==='unsuspend'){if(!authorUser)throw Object.assign(new Error('投稿者アカウントが存在しません。'),{status:404});authorUser.boardPostingSuspended=false;report.status='resolved';report.handledAt=Date.now();report.action='unsuspend'}else{report.status='resolved';report.handledAt=Date.now();report.action='dismiss'}});if(boardChanged)emit('board',{id:report.targetIslandId});emit('moderation',{islandId:report.realAuthorIslandId});return json(res,200,{ok:true,report:adminReportView(report)})
  }
  if(url.pathname==='/api/register'&&req.method==='POST'){const b=await readBody(req),username=String(b.username||'').trim(),password=String(b.password||''),islandName=normalizeIslandNameInput(b.islandName),avatarId=String(b.avatarId||DEFAULT_AVATAR),requestedSeaId=Number(b.seaId||0);if(username.length<3||username.length>24||password.length<6)return json(res,400,{error:'入力値を確認してください（ID 3-24文字、PW 6文字以上）。'});const islandNameProblem=islandNameError(islandName);if(islandNameProblem)return json(res,400,{error:islandNameProblem});if(!AVATAR_IDS.has(avatarId))return json(res,400,{error:'島アイコンが不正です。'});let created;await mutate(()=>{normalizeSeaAvailability();const sea=requestedSeaId>0?seaById(requestedSeaId):registrationSea();if(!sea)throw Object.assign(new Error('指定した海域が見つかりません。'),{status:400});const before=islandsInSea(sea.id).length;if(before>=SEA_ISLAND_CAPACITY)throw Object.assign(new Error(`${sea.name}は満員です。空きのある海域を選んでください。`),{status:409});const existingUser=state.users.find(u=>u.username.toLowerCase()===username.toLowerCase());if(existingUser){const existingIsland=state.islands.find(i=>i.ownerId===existingUser.id);if(existingIsland)throw Object.assign(new Error('そのIDは使用済みです。'),{status:409});state.users=state.users.filter(u=>u.id!==existingUser.id)}if(state.islands.some(i=>i.seaId===sea.id&&i.name===islandName))throw Object.assign(new Error(`その島名は${sea.name}ですでに存在します。`),{status:409});if(before===0&&sea.turn===0){sea.lastTurnAt=nowSec();sea.startedAt=Date.now()}const user={id:rid('u'),username,passwordHash:hashPassword(password),createdAt:Date.now()};const island=migrateIsland({id:rid('island'),seaId:sea.id,ownerId:user.id,ownerName:username,name:islandName,avatarId,map:createClassicMap(),money:INITIAL_MONEY,food:INITIAL_FOOD,turn:sea.turn,plans:[],logs:[],updatedAt:Date.now(),absent:0,prize:'0,0,'});island.logs.unshift({id:rid('log'),turn:sea.turn,at:Date.now(),text:`${sea.name}で島が発見されました。Hakoniwa R.A.の開発を始めましょう。`});state.users.push(user);state.islands.push(island);normalizeSeaAvailability();created={user,island,sea}});emit('islands',{reason:'register',seaId:created.sea.id});return json(res,201,{token:signToken({uid:created.user.id,exp:nowSec()+60*60*24*30}),island:publicIsland(created.island,true,true),sea:publicSea(created.sea)})}
    if(url.pathname==='/api/login'&&req.method==='POST'){const b=await readBody(req),user=state.users.find(u=>u.username.toLowerCase()===String(b.username||'').trim().toLowerCase());if(!user||!checkPassword(String(b.password||''),user.passwordHash))return json(res,401,{error:'IDまたはパスワードが違います。'});return json(res,200,{token:signToken({uid:user.id,exp:nowSec()+60*60*24*30})})}
  if(url.pathname==='/api/account'&&req.method==='DELETE'){
    const user=auth(req);if(!user)return json(res,401,{error:'ログインが必要です。'});const island=state.islands.find(i=>i.ownerId===user.id);if(!island)return json(res,404,{error:'島が存在しません。'});const b=await readBody(req);if(!checkPassword(String(b.password||''),user.passwordHash))return json(res,401,{error:'パスワードが違います。'});if(String(b.confirmIslandName||'').trim()!==island.name)return json(res,400,{error:'確認用の島名が一致しません。'});const islandId=island.id,userId=user.id;
    await recordDeletion(userId,islandId);await mutate(()=>{for(const target of state.islands){target.board=(target.board||[]).filter(post=>realAuthorId(post)!==islandId);if(target.boardRead&&typeof target.boardRead==='object')delete target.boardRead[islandId];if(target.intel&&typeof target.intel==='object')delete target.intel[islandId];target.plans=(target.plans||[]).filter(p=>p.targetId!==islandId)}state.boardReports=(state.boardReports||[]).filter(r=>r.reporterUserId!==userId&&r.reporterIslandId!==islandId&&r.realAuthorIslandId!==islandId&&r.targetIslandId!==islandId);state.supportMessages=(state.supportMessages||[]).filter(m=>m.userId!==userId&&m.islandId!==islandId);state.islands=state.islands.filter(i=>i.id!==islandId);state.users=state.users.filter(u=>u.id!==userId)});try{await scrubBackupsByLedger()}catch(e){console.error('backup scrub failed; deletion ledger still prevents restore',e)}emit('islands',{reason:'account-delete'});return json(res,200,{ok:true,backupResurrectionProtected:true})
  }
  if(url.pathname==='/api/me'&&req.method==='GET'){const user=auth(req);if(!user)return json(res,401,{error:'ログインが必要です。'});const island=islandForUser(user);if(!island)return json(res,404,{error:'島が存在しません。'});return json(res,200,{user:{id:user.id,username:user.username,...publicModeration(user)},sea:publicSea(seaForIsland(island)),island:{...publicIsland(island,true,true),boardUnread:boardUnreadCount(island,user)}})}
  if(url.pathname==='/api/islands'&&req.method==='GET'){const user=auth(req),sea=resolveSeaForRequest(req,url);return json(res,200,{turn:sea.turn,sea:publicSea(sea),islands:islandsInSea(sea.id).map(i=>({...publicIsland(i),boardUnread:boardUnreadCount(i,user)})).sort((a,b)=>b.population-a.population)});}
  const im=url.pathname.match(/^\/api\/islands\/([^/]+)$/);if(im&&req.method==='GET'){const island=state.islands.find(i=>i.id===im[1]);if(!island)return json(res,404,{error:'島が見つかりません。'});const u=auth(req),owner=!!u&&island.ownerId===u.id;const viewer=u?state.islands.find(i=>i.ownerId===u.id):null;const intel=!!viewer&&viewer.seaId===island.seaId&&!owner&&hasIntel(viewer,island.id,turnForIsland(viewer));return json(res,200,{island:{...publicIsland(island,true,owner,intel),boardUnread:boardUnreadCount(island,u)}})}
  if(im&&req.method==='PATCH'){const user=auth(req);if(!user)return json(res,401,{error:'ログインが必要です。'});const island=state.islands.find(i=>i.id===im[1]&&i.ownerId===user.id);if(!island)return json(res,403,{error:'自分の島だけ変更できます。'});const b=await readBody(req);const hasAvatar=Object.prototype.hasOwnProperty.call(b,'avatarId'),hasStatus=Object.prototype.hasOwnProperty.call(b,'statusMessage');if(!hasAvatar&&!hasStatus)return json(res,400,{error:'変更内容がありません。'});let avatarId=island.avatarId,statusMessage=island.statusMessage||'';if(hasAvatar){avatarId=String(b.avatarId||'');if(!AVATAR_IDS.has(avatarId))return json(res,400,{error:'島アイコンが不正です。'});}if(hasStatus){statusMessage=String(b.statusMessage||'').replace(/[\r\n]+/g,' ').trim();if(statusMessage.length>STATUS_TEXT_MAX)return json(res,400,{error:`一言コメントは${STATUS_TEXT_MAX}文字以内です。`});}await mutate(()=>{if(hasAvatar)island.avatarId=avatarId;if(hasStatus)island.statusMessage=statusMessage;island.updatedAt=Date.now()});emit('islands',{reason:'profile'});emit('island',{id:island.id});return json(res,200,{island:publicIsland(island,true,true)})}
  const rn=url.pathname.match(/^\/api\/islands\/([^/]+)\/rename$/);
  if(rn&&req.method==='POST'){
    const user=auth(req);if(!user)return json(res,401,{error:'ログインが必要です。'});
    const island=state.islands.find(i=>i.id===rn[1]&&i.ownerId===user.id);if(!island)return json(res,403,{error:'自分の島だけ変更できます。'});if(island.dead)return json(res,400,{error:'無人島になった島の名前は変更できません。'});
    const b=await readBody(req),newName=normalizeIslandNameInput(b.name),problem=islandNameError(newName);if(problem)return json(res,400,{error:problem});if(newName===island.name)return json(res,400,{error:'現在と同じ島名です。'});
    let oldName;await mutate(()=>{const live=state.islands.find(i=>i.id===rn[1]&&i.ownerId===user.id);if(!live)throw Object.assign(new Error('島が見つかりません。'),{status:404});if(live.dead)throw Object.assign(new Error('無人島になった島の名前は変更できません。'),{status:400});if(state.islands.some(i=>i.id!==live.id&&i.seaId===live.seaId&&i.name===newName))throw Object.assign(new Error(`${seaForIsland(live)?.name||seaName(live.seaId)}には「${newName}島」がすでに存在します。`),{status:409});if(live.money<ISLAND_RENAME_COST)throw Object.assign(new Error(`資金が不足しています（島名変更には ${ISLAND_RENAME_COST.toLocaleString('ja-JP')}億円必要です）。`),{status:400});oldName=live.name;live.money-=ISLAND_RENAME_COST;live.name=newName;live.updatedAt=Date.now();const turn=turnForIsland(live),at=Date.now(),text=`${oldName}島は${newName}島へ改称しました。`;live.logs??=[];live.logs.unshift({id:rid('log'),turn,at,text});live.logs=live.logs.slice(0,150);const sea=seaForIsland(live);if(sea){sea.globalLogs??=[];sea.globalLogs.unshift({turn,at,text});sea.globalLogs=sea.globalLogs.slice(0,80)}});
    const affectedBoards=state.islands.filter(target=>(target.board||[]).some(post=>realAuthorId(post)===island.id||post.spyIslandId===island.id)).map(target=>target.id);emit('islands',{reason:'rename',seaId:island.seaId});emit('island',{id:island.id});for(const id of affectedBoards)emit('board',{id,reason:'rename'});return json(res,200,{ok:true,cost:ISLAND_RENAME_COST,oldName,island:publicIsland(island,true,true)});
  }
  const bm=url.pathname.match(/^\/api\/islands\/([^/]+)\/board$/);
  if(bm&&req.method==='GET'){
    const island=state.islands.find(i=>i.id===bm[1]);if(!island)return json(res,404,{error:'島が見つかりません。'});
    const user=auth(req);return json(res,200,{posts:publicBoard(island,user),unread:boardUnreadCount(island,user),maxPosts:BOARD_MAX,maxText:BOARD_TEXT_MAX});
  }
  if(bm&&req.method==='POST'){
    const user=auth(req);if(!user)return json(res,401,{error:'投稿にはログインが必要です。'});
    const authorIsland=state.islands.find(i=>i.ownerId===user.id);if(!authorIsland)return json(res,403,{error:'投稿できる島がありません。'});
    if(user.boardPostingSuspended)return json(res,403,{error:'管理者により掲示板への投稿が停止されています。'});
    const target=state.islands.find(i=>i.id===bm[1]);if(!target)return json(res,404,{error:'島が見つかりません。'});if(target.seaId!==authorIsland.seaId)return json(res,400,{error:'別の海域の掲示板には投稿できません。'});
    const b=await readBody(req),text=String(b.text||'').trim(),mode=String(b.mode||b.visibility||'public');
    if(!text||text.length>BOARD_TEXT_MAX)return json(res,400,{error:`伝言は1〜${BOARD_TEXT_MAX}文字で入力してください。`});
    if(blockedBoardWord(text))return json(res,400,{error:'利用できない表現が含まれています。表現を変えて投稿してください。'});
    if(!['public','private','spy'].includes(mode))return json(res,400,{error:'投稿種別が不正です。'});
    if(mode==='spy'&&target.id===authorIsland.id)return json(res,400,{error:'自分の掲示板には諜報コメントを送れません。'});
    let spyIsland=null;
    if(mode==='spy'){
      const spyIslandId=String(b.spyIslandId||'');spyIsland=state.islands.find(i=>i.id===spyIslandId&&i.seaId===authorIsland.seaId);
      if(!spyIsland||spyIsland.id===authorIsland.id||spyIsland.id===target.id)return json(res,400,{error:'偽装する島を選び直してください。'});
    }
    const cost=mode==='private'?BOARD_PRIVATE_COST:mode==='spy'?BOARD_SPY_COST:0;
    let post;await mutate(()=>{
      if(authorIsland.money<cost)throw Object.assign(new Error(`資金が不足しています（必要 ${cost.toLocaleString('ja-JP')}億円）。`),{status:400});
      target.board??=[];
      const latest=target.board.find(x=>realAuthorId(x)===authorIsland.id);
      if(latest&&Date.now()-Number(latest.at||0)<2500)throw Object.assign(new Error('連続投稿は少し時間を空けてください。'),{status:429});
      authorIsland.money-=cost;authorIsland.updatedAt=Date.now();
      post={id:rid('msg'),turn:turnForIsland(authorIsland),at:Date.now(),text,visibility:mode==='public'?'public':'private',realAuthorIslandId:authorIsland.id,authorIslandId:authorIsland.id,authorIslandName:authorIsland.name,spyIslandId:spyIsland?.id||null,displayIslandName:spyIsland?.name||null,cost};
      target.board.unshift(post);target.board=target.board.slice(0,BOARD_MAX);target.updatedAt=Date.now();
    });
    emit('board',{id:target.id});emit('island',{id:authorIsland.id});emit('islands',{reason:'board-cost'});return json(res,201,{post:publicBoard(target,user).find(x=>x.id===post.id),cost});
  }
  const br=url.pathname.match(/^\/api\/islands\/([^/]+)\/board\/read$/);
  if(br&&req.method==='POST'){
    const user=auth(req);if(!user)return json(res,401,{error:'ログインが必要です。'});
    const viewerIsland=state.islands.find(i=>i.ownerId===user.id),target=state.islands.find(i=>i.id===br[1]);
    if(!viewerIsland)return json(res,403,{error:'閲覧できる島がありません。'});if(!target)return json(res,404,{error:'島が見つかりません。'});
    const b=await readBody(req),visible=publicBoard(target,user),maxVisible=visible.reduce((m,p)=>Math.max(m,Number(p.at||0)),0),requested=Number(b.throughAt||0);
    const through=Math.max(0,Math.min(requested||maxVisible,maxVisible||requested||0));
    await mutate(()=>{viewerIsland.boardRead??={};viewerIsland.boardRead[target.id]=Math.max(Number(viewerIsland.boardRead[target.id]||0),through);viewerIsland.updatedAt=Date.now()});
    return json(res,200,{ok:true,unread:boardUnreadCount(target,user),readThrough:viewerIsland.boardRead[target.id]||0});
  }
  const breport=url.pathname.match(/^\/api\/islands\/([^/]+)\/board\/([^/]+)\/report$/);
  if(breport&&req.method==='POST'){
    const user=auth(req);if(!user)return json(res,401,{error:'通報にはログインが必要です。'});const reporterIsland=state.islands.find(i=>i.ownerId===user.id);if(!reporterIsland)return json(res,403,{error:'通報できる島がありません。'});const target=state.islands.find(i=>i.id===breport[1]);if(!target)return json(res,404,{error:'島が見つかりません。'});const post=(target.board||[]).find(p=>p.id===breport[2]);if(!post)return json(res,404,{error:'伝言が見つかりません。'});if(!canViewBoardPost(target,post,user))return json(res,403,{error:'閲覧できない伝言は通報できません。'});const realId=realAuthorId(post);if(realId===reporterIsland.id)return json(res,400,{error:'自分の投稿は通報できません。'});const b=await readBody(req),reason=String(b.reason||'other'),detail=String(b.detail||'').trim();if(!BOARD_REPORT_REASONS[reason])return json(res,400,{error:'通報理由が不正です。'});if(detail.length>BOARD_REPORT_DETAIL_MAX)return json(res,400,{error:`通報補足は${BOARD_REPORT_DETAIL_MAX}文字以内です。`});if((state.boardReports||[]).some(r=>r.postId===post.id&&r.reporterUserId===user.id))return json(res,409,{error:'この投稿はすでに通報済みです。'});const real=state.islands.find(i=>i.id===realId),display=post.spyIslandId?state.islands.find(i=>i.id===post.spyIslandId):real;let report;await mutate(()=>{report={id:rid('report'),at:Date.now(),turn:turnForIsland(target),seaId:target.seaId,seaName:seaForIsland(target)?.name||seaName(target.seaId),status:'open',reason,reasonLabel:BOARD_REPORT_REASONS[reason],detail,targetIslandId:target.id,targetIslandName:target.name,postId:post.id,postText:post.text,postVisibility:post.visibility,reporterUserId:user.id,reporterIslandId:reporterIsland.id,reporterIslandName:reporterIsland.name,realAuthorIslandId:realId,realAuthorIslandName:real?.name||post.authorIslandName||'消滅した島',displayAuthorIslandId:display?.id||post.spyIslandId||post.authorIslandId,displayAuthorIslandName:display?.name||post.displayIslandName||post.authorIslandName||'消滅した島',wasSpy:!!post.spyIslandId};state.boardReports??=[];state.boardReports.unshift(report);state.boardReports=state.boardReports.slice(0,BOARD_REPORT_MAX)});return json(res,201,{ok:true,reportId:report.id})
  }
  const bd=url.pathname.match(/^\/api\/islands\/([^/]+)\/board\/([^/]+)$/);
  if(bd&&req.method==='DELETE'){
    const user=auth(req);if(!user)return json(res,401,{error:'ログインが必要です。'});
    const target=state.islands.find(i=>i.id===bd[1]);if(!target)return json(res,404,{error:'島が見つかりません。'});
    const viewerIsland=state.islands.find(i=>i.ownerId===user.id),post=(target.board||[]).find(x=>x.id===bd[2]);
    if(!post)return json(res,404,{error:'伝言が見つかりません。'});
    const allowed=target.ownerId===user.id||(viewerIsland&&realAuthorId(post)===viewerIsland.id);if(!allowed)return json(res,403,{error:'この伝言は削除できません。'});
    await mutate(()=>{target.board=target.board.filter(x=>x.id!==post.id);target.updatedAt=Date.now()});emit('board',{id:target.id});return json(res,200,{ok:true});
  }
  const pm=url.pathname.match(/^\/api\/islands\/([^/]+)\/plans$/);
  if(pm&&req.method==='PATCH'){
    const user=auth(req);if(!user)return json(res,401,{error:'ログインが必要です。'});
    const island=state.islands.find(i=>i.id===pm[1]&&i.ownerId===user.id);if(!island)return json(res,403,{error:'自分の島だけ操作できます。'});
    const b=await readBody(req),order=Array.isArray(b.order)?b.order.map(String):[];
    const currentIds=island.plans.map(p=>p.id);if(order.length!==currentIds.length||new Set(order).size!==order.length||order.some(id=>!currentIds.includes(id)))return json(res,409,{error:'計画キューが更新されています。再読み込みしてやり直してください。'});
    await mutate(()=>{const byId=new Map(island.plans.map(p=>[p.id,p]));island.plans=order.map(id=>byId.get(id));island.updatedAt=Date.now()});emit('island',{id:island.id});return json(res,200,{plans:island.plans});
  }
  if(pm&&req.method==='POST'){const user=auth(req);if(!user)return json(res,401,{error:'ログインが必要です。'});const island=state.islands.find(i=>i.id===pm[1]&&i.ownerId===user.id);if(!island)return json(res,403,{error:'自分の島だけ操作できます。'});const b=await readBody(req),cmd=COMMANDS[b.kind];if(!cmd)return json(res,400,{error:'不明な計画です。'});if(cmd.target&&b.targetId){const target=state.islands.find(i=>i.id===String(b.targetId));if(!target||target.seaId!==island.seaId)return json(res,400,{error:'対象は同じ海域の島から選んでください。'});}await mutate(()=>{if(cmd.auto){addAutoPlans(island,b.kind,b.amount)}else{if(island.plans.length>=MAX_PLANS)throw Object.assign(new Error(`計画は${MAX_PLANS}件までです。`),{status:400});island.plans.push({id:rid('plan'),kind:b.kind,x:Number.isFinite(Number(b.x))?Number(b.x):0,y:Number.isFinite(Number(b.y))?Number(b.y):0,targetId:b.targetId||null,amount:Math.max(0,Number(b.amount)||0),createdAt:Date.now()})}island.updatedAt=Date.now()});emit('island',{id:island.id});return json(res,201,{plans:island.plans})}
  const pd=url.pathname.match(/^\/api\/islands\/([^/]+)\/plans\/([^/]+)$/);if(pd&&req.method==='DELETE'){const user=auth(req);if(!user)return json(res,401,{error:'ログインが必要です。'});const island=state.islands.find(i=>i.id===pd[1]&&i.ownerId===user.id);if(!island)return json(res,403,{error:'自分の島だけ操作できます。'});await mutate(()=>{island.plans=island.plans.filter(p=>p.id!==pd[2])});emit('island',{id:island.id});return json(res,200,{plans:island.plans})}
  if(url.pathname==='/api/debug/advance'&&req.method==='POST'){if(!DEBUG_TURN)return json(res,404,{error:'disabled'});const sea=resolveSeaForRequest(req,url);await advanceSeaTurn(sea.id);const updated=seaById(sea.id);return json(res,200,{seaId:updated.id,turn:updated.turn})}
  if(req.method==='GET'&&await serveStatic(req,res,url.pathname))return;
  if(req.method==='GET'&&url.pathname.startsWith('/assets/'))return json(res,404,{error:'Asset not found'});
  if(req.method==='GET'){await serveStatic(req,res,'/index.html');return}
  return json(res,404,{error:'Not found'});
}catch(e){console.error(e);json(res,e.status||500,{error:e.message||'Server error'})}});

await load();setInterval(()=>maybeAdvance().catch(console.error),10_000).unref();server.listen(PORT,()=>console.log(`Hakoniwa R.A. Mobile: http://localhost:${PORT} turn=${TURN_SECONDS}s`));
