const API_BASE=String(window.HAKONIWA_CONFIG?.apiBase||'').replace(/\/$/,'');
const apiUrl=p=>API_BASE&&p.startsWith('/')?`${API_BASE}${p}`:p;
export async function legalInfo(){try{const r=await fetch(apiUrl('/api/legal'),{headers:{Accept:'application/json'}});if(!r.ok)throw new Error();return await r.json()}catch{return {operatorName:'Hakoniwa R.A. Mobile 運営',supportEmail:'',policyUpdated:'2026-08-19'}}}
export async function sendSupport(payload){const token=localStorage.getItem('hakoniwa_token')||'';const r=await fetch(apiUrl('/api/support'),{method:'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:`Bearer ${token}`}:{})},body:JSON.stringify(payload)});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||`HTTP ${r.status}`);return d}
