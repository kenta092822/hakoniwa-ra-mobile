const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
function normalizeIslandNameInput(value){return String(value||'').trim().replace(/島+$/u,'').trim()}
let token=localStorage.getItem('hakoniwa_token')||'',meta=null,current=null,mine=null,meUser=null,islands=[],selected={x:null,y:null},authMode='login',authAvatarId='tropical',settingsAvatarId='tropical',reportPostId=null;
let islandTab='map',logFilter='all',logQuery='',mapPreviewSeq=0,mapPreviewingTarget=false,mapShownIslandId=null,boardVisibility='public',boardPosts=[],commandSheetExpanded=false;
let lastCommandKind=localStorage.getItem('hakoniwa_last_command')||'',toastTimer=null;
const ATTACK_TARGET_COMMANDS=new Set(['missile','pp','spp','st','landmissile','uplift','nuclear','satelliteLaser','sendMonster','espionage']);
const API_BASE=String(window.HAKONIWA_CONFIG?.apiBase||'').replace(/\/$/,'');
function apiUrl(url){return API_BASE&&String(url).startsWith('/')?`${API_BASE}${url}`:url}
async function api(url,opt={}){const headers={'Content-Type':'application/json',...(opt.headers||{})};if(token)headers.Authorization=`Bearer ${token}`;const r=await fetch(apiUrl(url),{...opt,headers});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||`HTTP ${r.status}`);return d}
function toast(t,{success=false}={}){const el=$('#toast');if(!el)return;clearTimeout(toastTimer);el.textContent=`${success?'✓ ':''}${t}`;el.classList.toggle('success',success);el.classList.remove('hidden');toastTimer=setTimeout(()=>el.classList.add('hidden'),2200)}
function showScreen(s){$$('.screen').forEach(e=>e.classList.toggle('active',e.id===s));syncCommandDockState?.();scrollTo({top:0,behavior:'smooth'})}
function escapeHtml(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function formatInt(v){return Math.trunc(Number(v||0)).toLocaleString('ja-JP')}
function scaledText(v,multiplier,unit){return `${formatInt(Number(v||0)*multiplier)}${unit}`}
function popText(v){return scaledText(v,100,'人')}
function areaText(v){return scaledText(v,100,'万坪')}
function foodText(v){return scaledText(v,100,'トン')}
function facilityText(v){return scaledText(v,1000,'人')}
function avatarById(id){return meta?.avatars?.find(a=>a.id===id)||meta?.avatars?.[0]||{id:'tropical',name:'南国の小島',src:'/avatars/tropical.png'}}
function renderAvatarPicker(selector,selectedId,onSelect){const el=$(selector);if(!el)return;const avatars=meta?.avatars||[];el.innerHTML=avatars.map(a=>`<button class="avatar-choice${a.id===selectedId?' selected':''}" type="button" data-avatar="${a.id}" title="${escapeHtml(a.name)}"><img src="${a.src}" alt=""><span>${escapeHtml(a.name)}</span></button>`).join('');[...el.querySelectorAll('[data-avatar]')].forEach(b=>b.onclick=()=>{[...el.querySelectorAll('[data-avatar]')].forEach(x=>x.classList.toggle('selected',x===b));onSelect?.(b.dataset.avatar)})}
async function refreshMeta(){meta=await api('/api/meta');const sea=meta.sea||{id:1,name:'第1海域',islandCount:0,maxIslands:meta.maxIslands||30};$('#turnBadge').textContent=`${sea.name} · Turn ${meta.turn}`;const seaTitle=$('#seaTitle');if(seaTitle)seaTitle.textContent=sea.name;const seaCapacity=$('#seaCapacity');if(seaCapacity)seaCapacity.textContent=`${Number(sea.islandCount||0)}/${Number(sea.maxIslands||meta.maxIslands||30)}島${sea.status==='full'?'・満員':''}`;$('#debugTurnBtn').classList.toggle('hidden',!meta.debugTurn);$('#ruleBadge').textContent=`R.A. 030314 / ${meta.maxPlans}計画 / 1海域${meta.maxIslandsPerSea||meta.maxIslands||30}島`;updateNextTurn()}
function updateNextTurn(){if(!meta)return;const next=(meta.lastTurnAt+meta.turnSeconds)*1000,s=Math.max(0,Math.ceil((next-Date.now())/1000)),h=Math.floor(s/3600),m=Math.floor(s%3600/60),sec=s%60;$('#nextTurn').textContent=`次ターン ${h?`${h}h `:''}${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`}
function topIslandBy(field){
  if(!islands.length)return null;
  return islands.reduce((best,island)=>{
    if(!best)return island;
    const currentValue=Number(island?.[field]||0),bestValue=Number(best?.[field]||0);
    if(currentValue>bestValue)return island;
    if(currentValue===bestValue&&String(island.name).localeCompare(String(best.name),'ja')<0)return island;
    return best;
  },null);
}
function topCupIsland(){
  const teams=islands.filter(i=>i.hakoniwaCup);
  if(!teams.length)return null;
  return teams.reduce((best,i)=>{if(!best)return i;const a=i.hakoniwaCup,b=best.hakoniwaCup;const av=Number(a.championships||0)*10000+Number(a.points||0)*100+Number(a.totalWins||0),bv=Number(b.championships||0)*10000+Number(b.points||0)*100+Number(b.totalWins||0);return av>bv?i:best;},null);
}
function cupStageText(stage){return({qualifying:'予選',quarterfinal:'準々決勝',semifinal:'準決勝',final:'決勝',champion:'優勝',eliminated:'敗退',offseason:'オフ'}[stage]||stage||'オフ')}
function renderHomeLeaders(){
  const el=$('#homeLeaders');
  if(!el)return;
  const leaders=[
    {label:'👥 人口1位',field:'population',format:i=>popText(i.population)},
    {label:'🏝️ 面積1位',field:'area',format:i=>areaText(i.area)},
    {label:'🚜 農場1位',field:'farm',format:i=>facilityText(i.farm)},
    {label:'🏭 工場1位',field:'factory',format:i=>facilityText(i.factory)},
    {label:'🧳 通算観光客1位',field:'tourists',format:i=>popText(i.tourists)}
  ];
  if(!islands.length){
    el.innerHTML='<div class="hero-leader"><span class="hero-leader-label">各部門トップ</span><strong class="hero-leader-name">まだ島がありません</strong><span class="hero-leader-value">最初の島を作ってランキングを始めましょう</span></div>';
    return;
  }
  const base=leaders.map(entry=>{
    const island=topIslandBy(entry.field);
    return `<div class="hero-leader"><span class="hero-leader-label">${entry.label}</span><strong class="hero-leader-name">${escapeHtml(island.name)}島</strong><span class="hero-leader-value">${entry.format(island)}</span></div>`;
  });
  const cup=topCupIsland();if(cup)base.push(`<div class="hero-leader cup-leader"><span class="hero-leader-label">🏆 Hakoniwa Cup</span><strong class="hero-leader-name">${escapeHtml(cup.name)}島</strong><span class="hero-leader-value">優勝 ${formatInt(cup.hakoniwaCup.championships)}回 / 今季 ${formatInt(cup.hakoniwaCup.points)}pt</span></div>`);
  el.innerHTML=base.join('');
}
async function refreshIslands(){
  const d=await api('/api/islands');islands=[...(d.islands||[])].sort((a,b)=>Number(b.points||0)-Number(a.points||0)||Number(b.population||0)-Number(a.population||0)||String(a.name).localeCompare(String(b.name),'ja'));if(meta&&d.sea){meta.sea=d.sea;meta.turn=d.turn;const seaCapacity=$('#seaCapacity');if(seaCapacity)seaCapacity.textContent=`${Number(d.sea.islandCount||0)}/${Number(d.sea.maxIslands||meta.maxIslands||30)}島${d.sea.status==='full'?'・満員':''}`;$('#turnBadge').textContent=`${d.sea.name} · Turn ${d.turn}`;}
  $('#islandList').innerHTML=islands.length?islands.map((i,n)=>`<button class="island-card" data-id="${i.id}"><img class="island-icon" src="${i.avatarUrl||'/avatars/tropical.png'}" alt="${escapeHtml(i.avatarName||'島アイコン')}"><span class="island-card-main"><strong>${escapeHtml(i.name)}島</strong>${i.statusMessage?`<span class="island-status">📝 ${escapeHtml(i.statusMessage)}</span>`:''}<span class="island-summary"><small>⭐ ポイント ${formatInt(i.points||0)}</small><small>👥 人口 ${popText(i.population)}</small><small>🏝️ 面積 ${areaText(i.area)}</small><small>💰 資金 ${formatInt(i.money)}億円</small><small>🌾 食料 ${foodText(i.food)}</small><small>🚜 農場 ${facilityText(i.farm)}</small><small>🏭 工場 ${facilityText(i.factory)}</small><small>⛏️ 採掘場 ${facilityText(i.mountain)}</small></span></span><span class="island-card-end">${Number(i.boardUnread||0)>0?`<span class="island-unread">💬 ${Math.min(99,Number(i.boardUnread))}${Number(i.boardUnread)>99?'+':''}</span>`:''}<span class="rank">#${n+1}</span></span></button>`).join(''):'<p>まだ島がありません。最初の島を作りましょう。</p>';
  renderHomeLeaders();
  $$('.island-card').forEach(b=>b.onclick=()=>openIsland(b.dataset.id));
  if(current){const listed=islands.find(i=>i.id===current.id);if(listed){current.boardUnread=Number(listed.boardUnread||0);renderBoardUnread()}}
}

async function refreshMine(){if(!token){mine=null;meUser=null;$('#loginBtn').textContent='ログイン';return null}try{const d=await api('/api/me');mine=d.island;meUser=d.user||null;$('#loginBtn').textContent='ログアウト';return mine}catch{token='';localStorage.removeItem('hakoniwa_token');mine=null;meUser=null;$('#loginBtn').textContent='ログイン';return null}}
function hideTileInfo(){const tip=$('#tileInfo');if(!tip)return;tip.classList.add('hidden');tip.removeAttribute('style')}
function showTileInfo(cell,x,y,c){const tip=$('#tileInfo'),panel=cell?.closest('.map-panel');if(!tip||!panel||!cell)return;tip.innerHTML=`<strong>(${x}, ${y})</strong><span>${escapeHtml(c.detail)}</span>`;tip.classList.remove('hidden');requestAnimationFrame(()=>{if(tip.classList.contains('hidden')||!cell.isConnected)return;const cr=cell.getBoundingClientRect(),pr=panel.getBoundingClientRect(),tr=tip.getBoundingClientRect(),gap=6;let left=cr.left-pr.left+cr.width/2-tr.width/2;left=Math.max(4,Math.min(left,pr.width-tr.width-4));let top=cr.top-pr.top-tr.height-gap;if(top<4)top=cr.bottom-pr.top+gap;if(top+tr.height>pr.height-4)top=Math.max(4,cr.top-pr.top+(cr.height-tr.height)/2);tip.style.left=`${left}px`;tip.style.top=`${top}px`})}
function renderMap(i,{context=null}={}){
  const map=$('#map'),cells=i.map.flat(),existing=[...map.querySelectorAll('.cell')];
  mapShownIslandId=i.id;
  if(existing.length!==cells.length){const frag=document.createDocumentFragment();cells.forEach(()=>{const b=document.createElement('button');b.className='cell';b.type='button';frag.appendChild(b)});map.replaceChildren(frag)}
  const buttons=[...map.querySelectorAll('.cell')];let selectedCell=null,selectedData=null;
  cells.forEach((c,n)=>{const x=n%i.map[0].length,y=Math.floor(n/i.map[0].length),b=buttons[n],imageName=c.image||'';b.dataset.land=c.kind;b.dataset.value=c.value;b.title=`(${x},${y}) ${c.detail}`;if(b.dataset.image!==imageName){b.dataset.image=imageName;b.style.backgroundImage=imageName?`url(/assets/${imageName})`:''}b.classList.toggle('fallback',!c.image);const isSelected=selected.x===x&&selected.y===y;b.classList.toggle('selected',isSelected);if(isSelected){selectedCell=b;selectedData={x,y,c}}b.onclick=()=>{selected={x,y};const prev=map.querySelector('.cell.selected');if(prev&&prev!==b)prev.classList.remove('selected');b.classList.add('selected');$('#selectedCoord').textContent=`(${x}, ${y})`;$('#coord').textContent=`選択: (${x}, ${y}) ${c.detail}`;showTileInfo(b,x,y,c)}});
  $('#mapContext').textContent=context||`${i.name}島`;
  updatePlanMarkers();
  if(selectedCell&&selectedData)showTileInfo(selectedCell,selectedData.x,selectedData.y,selectedData.c);else hideTileInfo();
}
function renderPrizes(i){const a=i.prizes?.awards||[];$('#prizes').innerHTML=a.length?a.map(p=>`<span class="prize-badge" title="${escapeHtml(p.name)}"><img src="/assets/${p.image}" alt="">${escapeHtml(p.name)}</span>`).join(''):'<span class="small">受賞歴なし</span>'}
function renderStats(i){const sats=Object.values(i.satellites||{}).filter(s=>Number(s?.charge)>0);const satHtml=sats.length?`<span class="stat">🛰️ ${sats.map(s=>`${escapeHtml(s.name)} ${formatInt(s.charge)}`).join(' / ')}</span>`:'';const hc=i.hakoniwaCup;const cupHtml=hc?`<span class="stat cup-stat">⚽ HC ${cupStageText(hc.stage)} / 攻${formatInt(hc.offense)} 守${formatInt(hc.defense)} KP${formatInt(hc.keeper)} / ${formatInt(hc.seasonWins)}勝${formatInt(hc.seasonDraws)}分${formatInt(hc.seasonLosses)}敗 ${formatInt(hc.points)}pt / 優勝${formatInt(hc.championships)}回</span>`:'';const touristHtml=Number(i.tourists)>0?`<span class="stat">🧳 通算観光 ${popText(i.tourists)}</span>`:'';const b=i.biology;const bioHtml=b?`<span class="stat bio-stat">🧬 ${escapeHtml(b.name)} ${escapeHtml(b.status)} / HP+${formatInt(b.hpBonus)} 攻${formatInt(b.attack)} 守${formatInt(b.defense)} 速${formatInt(b.speed)} / ${formatInt(b.wins)}勝 EXP${formatInt(b.exp)}${b.currentHp!==null?` / 現HP${formatInt(b.currentHp)}`:''}</span>`:'';$('#stats').innerHTML=`<span class="stat">💰 ${formatInt(i.money)}億円</span><span class="stat">👥 ${popText(i.population)}</span><span class="stat">🌾 ${foodText(i.food)}</span><span class="stat">🏝️ ${areaText(i.area)}</span><span class="stat">⭐ 総合Point ${formatInt(i.points||0)}</span><span class="stat">🚜 農場 ${facilityText(i.farm)}</span>${Number(i.houses)>0?`<span class="stat">🏠 税率 ${formatInt(i.taxRate||0)}%</span>`:''}${Number(i.embassies)>0?`<span class="stat">🏛️ 大使館 ${formatInt(i.embassies)}</span>`:''}${touristHtml}${satHtml}${bioHtml}${cupHtml}`}
function planDesc(p){const c=meta.commands[p.kind]||{name:p.kind};let s=c.name;if(c.coord)s+=` (${p.x},${p.y})`;if(c.target){const t=islands.find(i=>i.id===p.targetId);if(t)s+=` → ${t.name}島`;}if(c.amount&&p.amount)s+=` ×${p.amount}`;return s}
function updatePlanMarkers(){
  const map=$('#map');if(!map)return;
  const buttons=[...map.querySelectorAll('.cell')];buttons.forEach(b=>{b.classList.remove('plan-marked');delete b.dataset.planMark});
  if(!mine||!meta||!mapShownIslandId||!Array.isArray(mine.plans))return;
  const marks=new Map();
  mine.plans.forEach((p,n)=>{const c=meta.commands[p.kind];if(!c?.coord)return;const belongs=c.target?p.targetId===mapShownIslandId:mapShownIslandId===mine.id;if(!belongs)return;const x=Number(p.x),y=Number(p.y);if(!Number.isInteger(x)||!Number.isInteger(y)||x<0||y<0||x>=meta.islandSize||y>=meta.islandSize)return;const key=`${x},${y}`;if(!marks.has(key))marks.set(key,[]);marks.get(key).push(n+1)});
  for(const [key,nums] of marks){const [x,y]=key.split(',').map(Number),b=buttons[y*meta.islandSize+x];if(!b)continue;b.classList.add('plan-marked');b.dataset.planMark=nums.length===1?String(nums[0]):`${nums[0]}+`;}
}
function renumberPlanDom(){[...$('#planList').querySelectorAll('.plan')].forEach((el,n)=>{const num=el.querySelector('.plan-num');if(num)num.textContent=String(n+1)})}
async function savePlanOrder(i){
  const order=[...$('#planList').querySelectorAll('.plan')].map(el=>el.dataset.planId);if(order.length!==i.plans.length)return;
  const old=[...i.plans],byId=new Map(old.map(p=>[p.id,p]));i.plans=order.map(id=>byId.get(id)).filter(Boolean);if(mine?.id===i.id)mine.plans=i.plans;if(current?.id===i.id)current.plans=i.plans;renumberPlanDom();updatePlanMarkers();
  try{const d=await api(`/api/islands/${i.id}/plans`,{method:'PATCH',body:JSON.stringify({order})});i.plans=d.plans||i.plans;if(mine?.id===i.id)mine.plans=i.plans;if(current?.id===i.id)current.plans=i.plans;renumberPlanDom();updatePlanMarkers();toast('計画順を変更しました',{success:true})}
  catch(e){i.plans=old;if(mine?.id===i.id)mine.plans=old;if(current?.id===i.id)current.plans=old;renderPlans(i);toast(e.message)}
}
function planDomOrder(){return [...$('#planList').querySelectorAll('.plan')].map(el=>el.dataset.planId)}
function movePlanAtY(list,dragging,clientY){
  const others=[...list.querySelectorAll('.plan')].filter(el=>el!==dragging);
  const before=others.find(el=>{const r=el.getBoundingClientRect();return clientY<r.top+r.height/2});
  if(before)list.insertBefore(dragging,before);else list.appendChild(dragging);
  renumberPlanDom();
  const lr=list.getBoundingClientRect();if(clientY<lr.top+40)list.scrollTop-=22;else if(clientY>lr.bottom-40)list.scrollTop+=22;
}
function bindPlanReorder(i){
  const list=$('#planList');if(!list)return;
  [...list.querySelectorAll('.plan-drag-handle')].forEach(handle=>{
    const item=()=>handle.closest('.plan');
    const finish=async(startOrder,dragging)=>{if(!dragging)return;dragging.classList.remove('dragging');const order=planDomOrder();if(order.join('|')!==startOrder.join('|'))await savePlanOrder(i)};
    const touchCapable=('ontouchstart' in window)||(navigator.maxTouchPoints||0)>0;
    if(touchCapable){
      let dragging=null,touchId=null,startOrder=[];
      handle.addEventListener('touchstart',e=>{const t=e.changedTouches[0];dragging=item();if(!dragging||!t)return;touchId=t.identifier;startOrder=planDomOrder();dragging.classList.add('dragging');e.preventDefault()},{passive:false});
      handle.addEventListener('touchmove',e=>{if(!dragging)return;const t=[...e.changedTouches].find(x=>x.identifier===touchId)||[...e.touches].find(x=>x.identifier===touchId);if(!t)return;movePlanAtY(list,dragging,t.clientY);e.preventDefault()},{passive:false});
      const endTouch=async e=>{if(!dragging)return;const t=[...e.changedTouches].find(x=>x.identifier===touchId);if(!t&&e.type!=='touchcancel')return;const d=dragging,old=startOrder;dragging=null;touchId=null;startOrder=[];await finish(old,d)};
      handle.addEventListener('touchend',endTouch,{passive:false});handle.addEventListener('touchcancel',endTouch,{passive:false});
    }else{
      let dragging=null,pointerId=null,startOrder=[];
      handle.onpointerdown=e=>{if(e.pointerType==='mouse'&&e.button!==0)return;dragging=item();if(!dragging)return;pointerId=e.pointerId;startOrder=planDomOrder();handle.setPointerCapture?.(pointerId);dragging.classList.add('dragging');e.preventDefault()};
      handle.onpointermove=e=>{if(!dragging||e.pointerId!==pointerId)return;movePlanAtY(list,dragging,e.clientY);e.preventDefault()};
      const endPointer=async e=>{if(!dragging||e.pointerId!==pointerId)return;const d=dragging,old=startOrder;dragging=null;try{handle.releasePointerCapture?.(pointerId)}catch{}pointerId=null;startOrder=[];await finish(old,d)};
      handle.onpointerup=endPointer;handle.onpointercancel=endPointer;
    }
    handle.onkeydown=async e=>{if(!['ArrowUp','ArrowDown'].includes(e.key))return;const row=item(),sib=e.key==='ArrowUp'?row.previousElementSibling:row.nextElementSibling;if(!sib)return;e.preventDefault();if(e.key==='ArrowUp')list.insertBefore(row,sib);else list.insertBefore(sib,row);renumberPlanDom();await savePlanOrder(i);handle.focus()};
  });
}
function renderPlans(i){
  $('#planCount').textContent=`${i.plans.length}/${meta.maxPlans}`;
  $('#planList').innerHTML=i.plans.length?i.plans.map((p,n)=>`<div class="plan" data-plan-id="${p.id}"><span class="plan-drag-handle" role="button" tabindex="0" aria-label="計画${n+1}をドラッグして並べ替え">≡</span><span class="plan-num">${n+1}</span><span class="plan-desc"><strong>${escapeHtml(planDesc(p))}</strong></span><button data-del="${p.id}" aria-label="計画を削除">×</button></div>`).join(''):'<p class="small">計画なし（資金繰りになります）</p>';
  $$('[data-del]').forEach(b=>b.onclick=async()=>{try{const d=await api(`/api/islands/${i.id}/plans/${b.dataset.del}`,{method:'DELETE'});i.plans=d.plans||[];if(mine?.id===i.id)mine.plans=i.plans;if(current?.id===i.id)current.plans=i.plans;renderPlans(i);toast('計画を削除しました',{success:true})}catch(e){toast(e.message)}});
  bindPlanReorder(i);updatePlanMarkers();
}
function logCategory(text){if(/受賞|ターン杯|Hakoniwa Cup|繁栄賞|平和賞|災難賞/.test(text))return'prize';if(/ミサイル|防衛施設|人造怪獣|難民|残骸|撃|諜報/.test(text))return'combat';if(/地震|津波|台風|隕石|噴火|地盤沈下|火災|怪獣|食料が不足|水没|自爆装置/.test(text))return'disaster';return'develop'}
function logCategoryMeta(category){return{develop:{label:'開発',icon:'🔧'},combat:{label:'戦闘',icon:'🚀'},disaster:{label:'災害',icon:'⚠️'},prize:{label:'受賞',icon:'🏆'}}[category]||{label:'記録',icon:'・'}}
function renderLogs(i){const source=i.logs||[];const q=logQuery.trim().toLowerCase();const filtered=source.filter(l=>{const category=logCategory(l.text);return(logFilter==='all'||category===logFilter)&&(!q||String(l.text).toLowerCase().includes(q)||String(l.turn).includes(q))});$('#logCount').textContent=`${filtered.length}/${source.length}件`;if(!filtered.length){$('#logs').innerHTML=`<div class="log-empty"><span>📭</span><strong>${source.length?'条件に合う記録はありません':'まだ出来事はありません'}</strong><small>${source.length?'絞り込みを変えてみてください':'ターンが進むとここに島の出来事が並びます'}</small></div>`;return}const groups=new Map();for(const l of filtered){if(!groups.has(l.turn))groups.set(l.turn,[]);groups.get(l.turn).push(l)}$('#logs').innerHTML=[...groups.entries()].map(([turn,items])=>`<section class="turn-log"><header class="turn-log-head"><strong>ターン ${turn}</strong><span>${items.length}件</span></header><div class="turn-log-body">${items.map(l=>{const category=logCategory(l.text),m=logCategoryMeta(category);return`<article class="log-entry log-${category}"><div class="log-entry-icon" aria-hidden="true">${m.icon}</div><div class="log-entry-main"><div class="log-entry-meta"><span class="log-type">${m.label}</span>${l.secret?'<span class="log-secret">🔒 機密</span>':''}</div><p>${escapeHtml(l.text)}</p></div></article>`}).join('')}</div></section>`).join('')}

function renderBoardUnread(){const badge=$('#boardUnreadBadge');if(!badge)return;const n=Math.max(0,Number(current?.boardUnread||0));if(n===0){badge.textContent='';badge.classList.add('hidden');badge.removeAttribute('aria-label');return}badge.textContent=n>99?'99+':String(n);badge.classList.remove('hidden');badge.setAttribute('aria-label',`未読${n}件`)}
async function markBoardRead(id){
  if(!mine||!id)return;const throughAt=boardPosts.reduce((m,p)=>Math.max(m,Number(p.at||0)),0);if(!throughAt)return;
  try{const d=await api(`/api/islands/${id}/board/read`,{method:'POST',body:JSON.stringify({throughAt})});if(current?.id===id){current.boardUnread=Number(d.unread||0);renderBoardUnread()}const listed=islands.find(i=>i.id===id);if(listed)listed.boardUnread=Number(d.unread||0);await refreshIslands();}
  catch{}
}
async function refreshBoard(id,{markRead=false}={}){
  if(!id)return;
  try{const d=await api(`/api/islands/${id}/board`);if(!current||current.id!==id)return;boardPosts=d.posts||[];current.boardUnread=Number(d.unread||0);renderBoard();renderBoardUnread();if(markRead)await markBoardRead(id);}
  catch(e){if(current?.id===id){boardPosts=[];renderBoard();toast(e.message)}}
}
function boardSpyChoices(){
  if(!mine||!current)return[];
  return islands.filter(i=>i.id!==mine.id&&i.id!==current.id);
}
function updateBoardSpyOptions(){
  const select=$('#boardSpyIsland'),button=$('[data-board-visibility="spy"]'),choices=boardSpyChoices();
  if(select){const prev=select.value;select.innerHTML='<option value="">偽装する島を選択</option>'+choices.map(i=>`<option value="${i.id}">${escapeHtml(i.name)}島</option>`).join('');if(prev&&choices.some(i=>i.id===prev))select.value=prev;}
  const disabled=!mine||!current||current.id===mine.id||choices.length===0;if(button)button.disabled=disabled;
  if(disabled&&boardVisibility==='spy')setBoardVisibility('public');
}
function renderBoard(){
  const list=$('#boardList');if(!list)return;
  const count=$('#boardCount');if(boardPosts.length){count.textContent=`${boardPosts.length}件`;count.classList.remove('hidden')}else{count.textContent='';count.classList.add('hidden')}
  const canPost=!!mine&&!meUser?.boardPostingSuspended;$('#boardComposer').classList.toggle('hidden',!canPost);$('#boardLoginNotice').classList.toggle('hidden',!!mine);$('#boardSuspendedNotice').classList.toggle('hidden',!mine||!meUser?.boardPostingSuspended);updateBoardSpyOptions();
  if(!boardPosts.length){list.innerHTML='<div class="board-empty">💬<strong>まだ伝言はありません</strong><small>最初のメッセージを残してみましょう。</small></div>';return}
  list.innerHTML=boardPosts.map(p=>`<article class="board-post${p.visibility==='private'?' private':''}"><div class="board-post-head"><button class="board-author" type="button" data-board-author="${p.authorIslandId}"><img src="${p.authorAvatarUrl||'/avatars/tropical.png'}" alt=""><span><strong>${escapeHtml(p.authorIslandName)}島</strong><small>ターン ${p.turn}${p.spyOwn?' ・ 🕵️ 偽装送信':''}</small></span></button><div class="board-post-actions"><span class="board-visibility ${p.visibility}">${p.visibility==='private'?'🔒 秘匿':'🌐 公開'}</span>${p.canReport?`<button class="board-report" type="button" data-board-report="${p.id}" aria-label="この伝言を通報">⚑</button>`:''}${p.canDelete?`<button class="board-delete" type="button" data-board-delete="${p.id}" aria-label="伝言を削除">×</button>`:''}</div></div><p>${escapeHtml(p.text)}</p></article>`).join('');
  $$('[data-board-author]').forEach(b=>b.onclick=()=>openIsland(b.dataset.boardAuthor));
  $$('[data-board-report]').forEach(b=>b.onclick=()=>openReportModal(b.dataset.boardReport));
  $$('[data-board-delete]').forEach(b=>b.onclick=async()=>{if(!current)return;try{await api(`/api/islands/${current.id}/board/${b.dataset.boardDelete}`,{method:'DELETE'});toast('伝言を削除しました',{success:true});await refreshBoard(current.id,{markRead:islandTab==='board'})}catch(e){toast(e.message)}});
}
function setBoardVisibility(v){
  boardVisibility=['public','private','spy'].includes(v)?v:'public';
  const spyDisabled=$('[data-board-visibility="spy"]')?.disabled;if(boardVisibility==='spy'&&spyDisabled)boardVisibility='public';
  $$('[data-board-visibility]').forEach(b=>b.classList.toggle('active',b.dataset.boardVisibility===boardVisibility));
  $('#boardSpyWrap').classList.toggle('hidden',boardVisibility!=='spy');
  const privateCost=Number(meta?.boardPrivateCost||100).toLocaleString('ja-JP'),spyCost=Number(meta?.boardSpyCost||1000).toLocaleString('ja-JP');
  $('#boardVisibilityHelp').textContent=boardVisibility==='private'?`秘匿：あなたとこの島の島主だけが読めます。送信時に${privateCost}億円消費します。`:boardVisibility==='spy'?`諜報：選んだ島になりすまして秘匿伝言を送ります。送信時に${spyCost}億円消費します。`:'公開：この掲示板を見る全員に表示されます。無料。';
}


function setCommandSheetExpanded(open){commandSheetExpanded=!!open;const panel=$('#commandPanel'),toggle=$('#commandSheetToggle');if(panel)panel.classList.toggle('sheet-expanded',commandSheetExpanded);if(toggle){toggle.setAttribute('aria-expanded',String(commandSheetExpanded));const grip=toggle.querySelector('.sheet-grip');if(grip)grip.textContent=commandSheetExpanded?'⌄':'☰'}}
function syncCommandDockState(){const own=!!mine&&!!current&&mine.id===current.id;const active=$('#island')?.classList.contains('active')&&islandTab==='map'&&own&&!$('#commandPanel')?.classList.contains('hidden');document.body.classList.toggle('has-command-dock',!!active);$('#commandPanel')?.classList.toggle('dock-active',!!active)}
function populateCommands(){if(!meta)return;const select=$('#commandSelect'),wanted=select.value||lastCommandKind;select.innerHTML=Object.entries(meta.commands).map(([k,v])=>`<option value="${k}">${v.name}${v.cost?`（${v.cost>0?v.cost+'億円':(-v.cost)+'00トン'}）`:''}</option>`).join('');if(wanted&&meta.commands[wanted])select.value=wanted;lastCommandKind=select.value;commandChanged({autoExpand:false})}
function attackTargetMode(){return ATTACK_TARGET_COMMANDS.has($('#commandSelect').value)}
async function showOwnMap({reset=false}={}){if(!mine||!current||current.id!==mine.id)return;if(reset||mapPreviewingTarget){selected={x:null,y:null};$('#selectedCoord').textContent='未選択';$('#coord').textContent='マスをタップ';hideTileInfo();}mapPreviewingTarget=false;renderMap(current,{context:'自分の島'});}
async function showSelectedTargetMap(){if(!mine||!attackTargetMode())return;const targetId=$('#targetSelect').value;if(!targetId)return showOwnMap({reset:true});const seq=++mapPreviewSeq;try{const d=await api(`/api/islands/${targetId}`);if(seq!==mapPreviewSeq||!attackTargetMode()||$('#targetSelect').value!==targetId)return;selected={x:null,y:null};mapPreviewingTarget=true;hideTileInfo();$('#selectedCoord').textContent='未選択';$('#coord').textContent=meta.commands[$('#commandSelect').value]?.coord?'標的のマスをタップ':'対象島を表示中';renderMap(d.island,{context:d.island.intelRevealed?`標的: ${d.island.name}島（諜報情報）`:`標的: ${d.island.name}島（公開マップ）`});}catch(e){toast(e.message)}}
async function commandChanged({autoExpand=false}={}){const k=$('#commandSelect').value,c=meta.commands[k];lastCommandKind=k;localStorage.setItem('hakoniwa_last_command',k);$('#targetWrap').classList.toggle('hidden',!c?.target);$('#amountWrap').classList.toggle('hidden',!c?.amount);if($('#amountLabel'))$('#amountLabel').textContent=c?.amountLabel||'数量 / 投資回数';if($('#amountHint'))$('#amountHint').textContent=c?.amountLabel?'番号・回数を指定してください。0 は既定値扱いです。':'0 は原作同様「既定値 / 撃てるだけ」扱い';$('#coordHint').classList.toggle('hidden',!c?.coord);const previous=$('#targetSelect').value;const choices=islands.filter(i=>!mine||i.id!==mine.id);$('#targetSelect').innerHTML=`<option value="">対象島を選択</option>`+choices.map(i=>`<option value="${i.id}">${escapeHtml(i.name)}島</option>`).join('');if(previous&&[...$('#targetSelect').options].some(o=>o.value===previous))$('#targetSelect').value=previous;else $('#targetSelect').value='';if(!$('#amount').value)$('#amount').value='0';if(autoExpand&&(c?.target||c?.amount))setCommandSheetExpanded(true);if(ATTACK_TARGET_COMMANDS.has(k)){await showSelectedTargetMap()}else{mapPreviewSeq++;await showOwnMap({reset:false})}}
function setIslandTab(tab,{scroll=true}={}){if(!['map','log','board'].includes(tab))tab='map';islandTab=tab;$$('[data-island-tab]').forEach(b=>{const on=b.dataset.islandTab===tab;b.classList.toggle('active',on);b.setAttribute('aria-selected',String(on))});$$('[data-island-view]').forEach(v=>v.classList.toggle('active',v.dataset.islandView===tab));syncCommandDockState();if(tab==='board'&&current)refreshBoard(current.id,{markRead:true});if(scroll){const tabs=$('#islandTabs');const y=Math.max(0,tabs.getBoundingClientRect().top+scrollY-58);scrollTo({top:y,behavior:'smooth'})}}
async function openIsland(id,keepSelected=false){const d=await api(`/api/islands/${id}`);current=d.island;if(!keepSelected){selected={x:null,y:null};hideTileInfo();}$('#islandName').textContent=`${current.name}島`;renderStats(current);renderPrizes(current);renderBoardUnread();renderMap(current,{context:mine&&mine.id===current.id?'自分の島':`${current.name}島（公開マップ）`});renderLogs(current);const own=mine&&mine.id===current.id;$('#commandPanel').classList.toggle('hidden',!own);$('#visitorPlanNotice').classList.toggle('hidden',own);$('#avatarSettingsBtn').classList.toggle('hidden',!own);if(own){$('#currentAvatarIcon').src=current.avatarUrl||'/avatars/tropical.png';$('#currentAvatarIcon').alt=current.avatarName||'島アイコン';renderPlans(current);populateCommands()}else setCommandSheetExpanded(false);boardPosts=[];renderBoard();showScreen('island');setIslandTab(islandTab,{scroll:false});if(islandTab!=='board')renderBoardUnread()}
async function loadRegistrationSeas(){const select=$('#registerSeaId');if(!select)return;select.innerHTML='<option value="">読み込み中…</option>';try{const d=await api('/api/seas');if(meta)meta.seas=d.seas;const recommended=d.registrationSea?.id;select.innerHTML=(d.seas||[]).map(sea=>{const full=!sea.registrationOpen;const tag=sea.id===recommended&&!full?'・おすすめ':'';return `<option value="${sea.id}" ${full?'disabled':''} ${sea.id===recommended&&!full?'selected':''}>${esc(sea.name)}（${Number(sea.islandCount||0)}/${Number(sea.maxIslands||30)}島${full?'・満員':tag}）</option>`}).join('');if(!select.value){const firstOpen=(d.seas||[]).find(s=>s.registrationOpen);if(firstOpen)select.value=String(firstOpen.id)}}catch(e){select.innerHTML='<option value="">海域を取得できません</option>';$('#authError').textContent=e.message}}
async function openAuth(mode){authMode=mode;$('#modal').classList.remove('hidden');$('#authError').textContent='';$('#islandNameWrap').classList.toggle('hidden',mode==='login');$('#seaSelectWrap').classList.toggle('hidden',mode==='login');$('#authAvatarWrap').classList.toggle('hidden',mode==='login');$('#modalTitle').textContent=mode==='register'?'新しい島を作る':'ログイン';$('#authSubmit').textContent=mode==='register'?'島を作成':'ログイン';$('#password').autocomplete=mode==='register'?'new-password':'current-password';if(mode==='register'){authAvatarId='tropical';renderAvatarPicker('#authAvatarPicker',authAvatarId,id=>authAvatarId=id);await loadRegistrationSeas()}}
function closeAuth(){$('#modal').classList.add('hidden')}
function renderModerationSettings(){const box=$('#moderationWarnings');if(!box)return;const warnings=meUser?.moderationWarnings||[];box.innerHTML=warnings.length?`<div class="moderation-warning"><strong>⚠️ 運営からの警告</strong>${warnings.slice(0,3).map(w=>`<p>${escapeHtml(w.message)}</p>`).join('')}</div>`:'';$('#postingSuspendedSetting').classList.toggle('hidden',!meUser?.boardPostingSuspended)}
function openAvatarSettings(){if(!mine||!meta)return;settingsAvatarId=mine.avatarId||'tropical';renderAvatarPicker('#avatarSettingsPicker',settingsAvatarId,id=>settingsAvatarId=id);const input=$('#statusMessageInput');input.maxLength=meta.statusTextMax||40;input.value=mine.statusMessage||'';$('#statusChars').textContent=`${input.value.length}/${input.maxLength}`;const rename=$('#renameIslandName');rename.maxLength=meta.islandNameMax||20;rename.value='';$('#renameIslandError').textContent='';const renameCost=Number(meta.islandRenameCost??500);$('#renameCostLabel').textContent=`${renameCost.toLocaleString('ja-JP')}億円`;$('#renameIslandBtn').textContent=`${renameCost.toLocaleString('ja-JP')}億円で島名を変更`;renderModerationSettings();$('#avatarModal').classList.remove('hidden')}
function closeAvatarSettings(){$('#avatarModal').classList.add('hidden')}
function openReportModal(postId){if(!mine||!current)return;reportPostId=postId;$('#reportReason').value='abuse';$('#reportDetail').value='';$('#reportError').textContent='';$('#reportModal').classList.remove('hidden')}
function closeReportModal(){reportPostId=null;$('#reportModal').classList.add('hidden')}
function openDeleteAccountModal(){if(!mine)return;$('#deleteAccountPassword').value='';$('#deleteAccountIslandName').value='';$('#deleteAccountHint').textContent=`確認のため「${mine.name}」と入力してください。`;$('#deleteAccountError').textContent='';$('#deleteAccountModal').classList.remove('hidden')}
function closeDeleteAccountModal(){$('#deleteAccountModal').classList.add('hidden')}
$('#authForm').onsubmit=async e=>{e.preventDefault();try{const body={username:$('#username').value,password:$('#password').value};if(authMode==='register'){body.islandName=normalizeIslandNameInput($('#newIslandName').value);body.avatarId=authAvatarId;body.seaId=Number($('#registerSeaId').value||0)||undefined;}const d=await api(authMode==='register'?'/api/register':'/api/login',{method:'POST',body:JSON.stringify(body)});token=d.token;localStorage.setItem('hakoniwa_token',token);closeAuth();await Promise.all([refreshMine(),refreshIslands(),refreshMeta()]);toast(authMode==='register'?`${d.sea?.name||mine?.seaName||'海域'}に島を作成しました`:'ログインしました');if(mine)openIsland(mine.id)}catch(e){$('#authError').textContent=e.message}}
$('#newIslandBtn').onclick=()=>openAuth('register');
$('#modalClose').onclick=closeAuth;
$('#avatarSettingsBtn').onclick=openAvatarSettings;
$('#avatarModalClose').onclick=closeAvatarSettings;
$('#reportModalClose').onclick=closeReportModal;
$('#reportCancelBtn').onclick=closeReportModal;
$('#reportSubmitBtn').onclick=async()=>{if(!current||!reportPostId)return;try{await api(`/api/islands/${current.id}/board/${reportPostId}/report`,{method:'POST',body:JSON.stringify({reason:$('#reportReason').value,detail:$('#reportDetail').value.trim()})});closeReportModal();toast('通報を受け付けました',{success:true})}catch(e){$('#reportError').textContent=e.message}};
$('#deleteAccountBtn').onclick=openDeleteAccountModal;
$('#deleteAccountModalClose').onclick=closeDeleteAccountModal;
$('#deleteAccountCancelBtn').onclick=closeDeleteAccountModal;
$('#deleteAccountConfirmBtn').onclick=async()=>{if(!mine)return;const islandName=mine.name;if(!confirm(`${islandName}島とアカウントを完全に削除します。元に戻せません。実行しますか？`))return;try{await api('/api/account',{method:'DELETE',body:JSON.stringify({password:$('#deleteAccountPassword').value,confirmIslandName:$('#deleteAccountIslandName').value.trim()})});token='';localStorage.removeItem('hakoniwa_token');mine=null;meUser=null;current=null;closeDeleteAccountModal();closeAvatarSettings();$('#loginBtn').textContent='ログイン';await refreshIslands();showScreen('home');toast('アカウントを削除しました',{success:true})}catch(e){$('#deleteAccountError').textContent=e.message}};
$('#statusMessageInput').addEventListener('input',e=>{$('#statusChars').textContent=`${e.target.value.length}/${e.target.maxLength}`});
$('#saveAvatarBtn').onclick=async()=>{if(!mine)return;try{const statusMessage=$('#statusMessageInput').value.replace(/[\r\n]+/g,' ').trim();const d=await api(`/api/islands/${mine.id}`,{method:'PATCH',body:JSON.stringify({avatarId:settingsAvatarId,statusMessage})});mine=d.island;if(current?.id===mine.id)current=d.island;closeAvatarSettings();await refreshIslands();$('#currentAvatarIcon').src=d.island.avatarUrl;toast('島プロフィールを更新しました',{success:true})}catch(e){toast(e.message)}};
$('#renameIslandBtn').onclick=async()=>{if(!mine||!meta)return;const newName=normalizeIslandNameInput($('#renameIslandName').value),cost=Number(meta.islandRenameCost??500);$('#renameIslandError').textContent='';if(!newName)return $('#renameIslandError').textContent='新しい島名を入力してください。';if(newName===mine.name)return $('#renameIslandError').textContent='現在と同じ島名です。';if(!confirm(`${mine.name}島を「${newName}島」へ変更します。${cost.toLocaleString('ja-JP')}億円を消費します。よろしいですか？`))return;try{const d=await api(`/api/islands/${mine.id}/rename`,{method:'POST',body:JSON.stringify({name:newName})});mine=d.island;if(current?.id===mine.id){current=d.island;$('#islandName').textContent=`${mine.name}島`;renderStats(mine);renderLogs(mine)}$('#renameIslandName').value='';await refreshIslands();toast(`${d.oldName}島から${mine.name}島へ改称しました（${Number(d.cost||cost).toLocaleString('ja-JP')}億円）`,{success:true})}catch(e){$('#renameIslandError').textContent=e.message}};
$('#backBtn').onclick=()=>showScreen('home');
$('#commandSelect').onchange=()=>commandChanged({autoExpand:false});
$('#targetSelect').onchange=()=>{if(attackTargetMode())showSelectedTargetMap()};
$('#commandSheetToggle').onclick=()=>setCommandSheetExpanded(!commandSheetExpanded);
$('#loginBtn').onclick=async()=>{if(token){token='';localStorage.removeItem('hakoniwa_token');mine=null;meUser=null;$('#loginBtn').textContent='ログイン';toast('ログアウトしました');showScreen('home');await refreshIslands()}else openAuth('login')};
async function goMine(){if(!mine)await refreshMine();if(mine){islandTab='map';openIsland(mine.id)}else openAuth('login')}
const myIslandBtn=$('#myIslandBtn');if(myIslandBtn)myIslandBtn.onclick=goMine;$('#navMine').onclick=goMine;$$('[data-screen]').forEach(b=>b.onclick=()=>showScreen(b.dataset.screen));
$$('[data-island-tab]').forEach(b=>b.onclick=()=>setIslandTab(b.dataset.islandTab));
$$('[data-log-filter]').forEach(b=>b.onclick=()=>{logFilter=b.dataset.logFilter;$$('[data-log-filter]').forEach(x=>x.classList.toggle('active',x===b));if(current)renderLogs(current)});
$('#logSearch').addEventListener('input',e=>{logQuery=e.target.value;if(current)renderLogs(current)});
$$('[data-board-visibility]').forEach(b=>b.onclick=()=>setBoardVisibility(b.dataset.boardVisibility));
$('#boardText').addEventListener('input',e=>{$('#boardChars').textContent=`${e.target.value.length}/${meta?.boardTextMax||200}`});
$('#boardPostBtn').onclick=async()=>{if(!mine||!current)return;const text=$('#boardText').value.trim();if(!text)return toast('伝言を入力してください');const mode=boardVisibility,spyIslandId=$('#boardSpyIsland').value;if(mode==='spy'&&!spyIslandId)return toast('偽装する島を選択してください');try{const d=await api(`/api/islands/${current.id}/board`,{method:'POST',body:JSON.stringify({text,mode,spyIslandId:mode==='spy'?spyIslandId:null})});$('#boardText').value='';$('#boardChars').textContent=`0/${meta?.boardTextMax||200}`;const message=mode==='spy'?`諜報コメントを送信しました（${Number(d.cost||meta?.boardSpyCost||1000).toLocaleString('ja-JP')}億円）`:mode==='private'?`秘匿伝言を送りました（${Number(d.cost||meta?.boardPrivateCost||100).toLocaleString('ja-JP')}億円）`:'伝言を投稿しました';setBoardVisibility('public');await refreshMine();toast(message,{success:true});await refreshBoard(current.id,{markRead:true});await refreshIslands()}catch(e){toast(e.message)}};
function planAddedToast(kind,c){if(c.auto)return'自動計画を反映しました';if(c.coord&&selected.x!=null&&selected.y!=null)return`(${selected.x}, ${selected.y}) ${c.name}を追加`;if(c.target){const t=islands.find(i=>i.id===$('#targetSelect').value);return`${t?`${t.name}島へ`:''}${c.name}を追加`}return`${c.name}を追加`}
$('#addPlanBtn').onclick=async()=>{if(!mine)return;const kind=$('#commandSelect').value,c=meta.commands[kind];if(c.coord&&(selected.x==null||selected.y==null))return toast(ATTACK_TARGET_COMMANDS.has(kind)?'標的島のマスをタップしてください':'先にマップのマスをタップしてください');if(c.target&&!$('#targetSelect').value)return toast('左の≡を開いて対象島を選択してください');try{const d=await api(`/api/islands/${mine.id}/plans`,{method:'POST',body:JSON.stringify({kind,x:selected.x,y:selected.y,targetId:$('#targetSelect').value||null,amount:Number($('#amount').value)||0})});mine.plans=d.plans||[];if(current?.id===mine.id){current.plans=mine.plans;renderPlans(current)}toast(planAddedToast(kind,c),{success:true})}catch(e){toast(e.message)}};
$('#debugTurnBtn').onclick=async()=>{await api('/api/debug/advance',{method:'POST'});toast('1ターン進めました',{success:true})};
const es=new EventSource(apiUrl('/api/events'));
es.addEventListener('turn',async()=>{await Promise.all([refreshMeta(),refreshIslands(),refreshMine()]);if(current)openIsland(current.id,true)});
es.addEventListener('islands',refreshIslands);
es.addEventListener('island',async e=>{const d=JSON.parse(e.data);if(current?.id!==d.id)return;try{const r=await api(`/api/islands/${d.id}`);if(current?.id!==d.id)return;current=r.island;$('#islandName').textContent=`${current.name}島`;renderStats(current);renderPrizes(current);renderLogs(current);renderBoardUnread();const own=mine&&mine.id===current.id;if(own){mine=current;renderPlans(current);$('#currentAvatarIcon').src=current.avatarUrl||'/avatars/tropical.png';$('#currentAvatarIcon').alt=current.avatarName||'島アイコン'}else $('#mapContext').textContent=`${current.name}島（公開マップ）`}catch{}});
es.addEventListener('board',async e=>{const d=JSON.parse(e.data);await refreshIslands();if(current?.id===d.id&&islandTab==='board')await refreshBoard(d.id,{markRead:true})});
es.addEventListener('moderation',async()=>{if(token){await refreshMine();if(current&&islandTab==='board')renderBoard()}});
setInterval(updateNextTurn,1000);if('serviceWorker'in navigator)navigator.serviceWorker.register('/sw.js').catch(()=>{});
await refreshMeta();await refreshIslands();await refreshMine();populateCommands();
