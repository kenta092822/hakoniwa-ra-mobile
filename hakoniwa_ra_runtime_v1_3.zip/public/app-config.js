// Web/PWA is same-origin. `npm run ios:prepare` overwrites only the copied iOS version.
window.HAKONIWA_CONFIG = Object.freeze({ apiBase: '' });
